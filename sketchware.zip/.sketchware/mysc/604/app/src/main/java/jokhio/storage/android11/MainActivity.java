package jokhio.storage.android11;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import java.io.*;
import java.util.zip.*;
import androidx.documentfile.provider.DocumentFile;
import android.provider.DocumentsContract;
import android.database.*;
import android.provider.DocumentsContract.Document;

public class MainActivity extends AppCompatActivity {
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private  Uri muri;
	private  static final int NEW_FOLDER_REQUEST_CODE = 43;
	private  Uri uri2;
	private  DocumentFile mfile;
	private  DocumentFile mfile1;
	private double PermissionNumber = 0;
	private String str = "";
	private  Uri parenturi ;
	private String currentLoc = "";
	private String lastLoc = "";
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private ListView listview1;
	private Button button1;
	private ImageView imageview1;
	private TextView textview1;
	private TextView textview2;
	
	private Intent i = new Intent();
	private SharedPreferences sp;
	private Intent i2 = new Intent();
	private AlertDialog.Builder dlg;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		listview1 = findViewById(R.id.listview1);
		button1 = findViewById(R.id.button1);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		textview2 = findViewById(R.id.textview2);
		sp = getSharedPreferences("PERMISSIONS", Activity.MODE_PRIVATE);
		dlg = new AlertDialog.Builder(this);
		
		linear2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				currentLoc = "";
				listmap.clear();
				if (updateDirectoryEntries(parenturi)) {
					listview1.setAdapter(new Listview1Adapter(listmap));
					((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				}
			}
		});
		
		linear3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				listmap.clear();
				if (lastLoc.length() > 0) {
					if (updateDirectoryEntries(parenturi, lastLoc)) {
						_refresh();
					}
				}
				else {
					if (updateDirectoryEntries(parenturi)) {
						_refresh();
					}
				}
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				muri = Uri.parse(sp.getString("DIRECT_FOLDER_URI", ""));
				_unzipAssets("testing.zip", muri);
			}
		});
	}
	
	private void initializeLogic() {
		
		imageview1.setColorFilter(0xFFF57F17, PorterDuff.Mode.MULTIPLY);
		/**
* if you do not know how to use these blocks watch out the playlist
* Android 11 storage access framework (SAF): https://www.youtube.com/playlist?list=PL7YwprXjrPWP6PDTwkz-xvpMloFr2Ocu_
* you need to add these import statements

1  android.database.*
2  java.io.*
3  android.provider.DocumentsContract
4  androidx.documentfile.provider.DocumentFile
5  android.provider.DocumentsContract.Document
6 java.util.zip.*


* 
* add this int as custom variable
* static final int NEW_FOLDER_REQUEST_CODE = 43
*
* you can declare Document file by creating custom variable
* example syntax 
*
* DocumentFile mfile
* 
*
* and for uri
*
*Uri muri
*
*
* to get list of files in a folder you may also need to add a map and a listmap
* 
**/
		try {
			muri = Uri.parse(sp.getString("DIRECT_FOLDER_URI", ""));
			    mfile = DocumentFile.fromTreeUri(this, muri);
			                    
			if (!mfile.canRead() || !mfile.canWrite()) {
				_askPermission(linear1);
			}
			else {
				parenturi = Uri.parse(sp.getString("FOLDER_URI", ""));
				if (updateDirectoryEntries(parenturi)) {
					listview1.setAdapter(new Listview1Adapter(listmap));
					((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				}
			}
		} catch (Exception e) {
			_askPermission(linear1);
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		    if (_resultCode == Activity.RESULT_OK) {
				            if (_data != null) {
						               muri = _data.getData();
						if (Uri.decode(muri.toString()).endsWith(":")) {
								SketchwareUtil.showMessage(getApplicationContext(), "can't use root folder please choose another");
								_askPermission(linear1);
						}
						else {
								final int takeFlags = i.getFlags()
								            & (Intent.FLAG_GRANT_READ_URI_PERMISSION
								            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
								// Check for the freshest data.
								getContentResolver().takePersistableUriPermission(muri, takeFlags);
								sp.edit().putString("FOLDER_URI", muri.toString()).commit();
								    mfile = DocumentFile.fromTreeUri(this, muri);
								                    
								    mfile1 = mfile.createFile("*/*", "test.file");
								    uri2 = mfile1.getUri();
								sp.edit().putString("DIRECT_FOLDER_URI", uri2.toString().substring((int)(0), (int)(uri2.toString().length() - 9))).commit();
								try{
										        DocumentsContract.deleteDocument(getApplicationContext().getContentResolver(), uri2);
										     
										        } catch (FileNotFoundException e) {
										         
										    }             
								parenturi = Uri.parse(sp.getString("FOLDER_URI", ""));
								if (updateDirectoryEntries(parenturi)) {
										listview1.setAdapter(new Listview1Adapter(listmap));
										((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
								}
						}
						       } else {
						        
						   }
				       } else {
				       SketchwareUtil.showMessage(getApplicationContext(), "aaah, have you refused the Permission!");
				finishAffinity();
				   }
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _askPermission(final View _view) {
		i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
		i.setAction(Intent.ACTION_OPEN_DOCUMENT_TREE);
		muri = Uri.parse("content://com.android.externalstorage.documents/tree/primary%3AAndroid/document/primary%3AAndroid%2Fdata");
		    i.putExtra(DocumentsContract.EXTRA_INITIAL_URI, muri);
		        startActivityForResult(i, NEW_FOLDER_REQUEST_CODE);
	}
	
	
	public void _extra() {
		
		
	}
	Boolean updateDirectoryEntries(Uri uri) {
		
		HashMap<String, Object> map = new HashMap<>();
		
		
		        
		ContentResolver contentResolver = getApplicationContext().getContentResolver();
		
		
		        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(uri,
		                DocumentsContract.getTreeDocumentId(uri));
		
		 
		
		        Cursor childCursor = contentResolver.query(childrenUri, new String[]{Document.COLUMN_DOCUMENT_ID,
			                Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE}, null, null, null);
		        try {
			            
			            while (childCursor.moveToNext()) {
				                
				
				
				final String docId = childCursor.getString(0);
									                final String name = childCursor.getString(1);
									                final String mime = childCursor.getString(2);
				
				
				map = new HashMap<>();
									                
									map.put("docId", docId);
									map.put("name", name);
									map.put("mime", mime);
						listmap.add(map);
						            }
				            
			        } finally {
			            closeQuietly(childCursor);
			        }
		return true;
		    }
	
	
	
	
	
	
	// SECOND METHOD TO GET ENTRIES FOR CHILDREN
	
	Boolean updateDirectoryEntries(Uri uri, String str) {
		
		HashMap<String, Object> map = new HashMap<>();
		
		 
		        
		ContentResolver contentResolver = getApplicationContext().getContentResolver();
		
		
		        Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(uri, str);
		
		 
		
		        Cursor childCursor = contentResolver.query(childrenUri, new String[]{Document.COLUMN_DOCUMENT_ID,
			                Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE}, null, null, null);
		        try {
			            
			            while (childCursor.moveToNext()) {
				                
				
				
				final String docId = childCursor.getString(0);
									                final String name = childCursor.getString(1);
									                final String mime = childCursor.getString(2);
				
				
				map = new HashMap<>();
									                
									map.put("docId", docId);
									map.put("name", name);
									map.put("mime", mime);
						listmap.add(map);
						            }
				            
			        } finally {
			            closeQuietly(childCursor);
			        }
		return true;
		    }
	
	
	
	// Util method to check if the mime type is a directory
	private static boolean isDirectory(String mimeType) {
		    return DocumentsContract.Document.MIME_TYPE_DIR.equals(mimeType);
	}
	
	
	// Util method to close a closeable
	private static void closeQuietly(Closeable closeable) {
		    if (closeable != null) {
			        try {
				            closeable.close();
				        } catch (RuntimeException re) {
				            throw re;
				        } catch (Exception ignore) {
				            // ignore exception
				        }
			    }
	}
	Boolean unzip (Uri _muri, DocumentFile _myDestFolder) {
		
		     Uri muri = _muri;
			  DocumentFile myFolder = null;
			DocumentFile mySubFolder = null;
			 DocumentFile mySubSubFolder = null;
		DocumentFile mySubSubSubFolder = null;
		DocumentFile mySubSubSubSubFolder = null;
		DocumentFile tempFile = null;
		
		try {
					try{
								InputStream is = getContentResolver().openInputStream(muri);
								BufferedInputStream bis = new BufferedInputStream(is);
								ZipInputStream zis = new ZipInputStream(bis);
								ZipEntry zipEntry;
								
								while ((zipEntry = zis.getNextEntry()) != null) {
											String fileName = null; 
											
											try {
														fileName = zipEntry.getName();        
														fileName = fileName.replace("\\",File.separator).replace("/",File.separator);
														int p=fileName.lastIndexOf(File.separator);        
														DocumentFile destFolder = _myDestFolder;
							                     //DocumentFile of the destination folder
														String destName = fileName;
														
														if (p>=0) {
																	String[] split = fileName.split(File.separator);
																	
																	//If the .zip file contains multiple folder levels, this is where you  
																	//have to check and then create them, e.g. for 4 levels:
																	
																	
																	
																	if(split.length==1) {
								if(myFolder==null) {
																							myFolder = _myDestFolder;
									
																				}
																				destFolder = myFolder;
																				destName = fileName;
																	} else if(split.length==2) {
								myFolder = _myDestFolder;
																				if(mySubFolder==null) {
									tempFile = null;
									tempFile = DocumentFile.fromSingleUri(this, Uri.parse(myFolder.getUri().toString().concat(Uri.encode("/").concat(split[0]))));
									
									
									
									if (tempFile.exists()) {
										
										mySubFolder = tempFile;
										
										
											
									}else {
										mySubFolder = myFolder.createDirectory(split[0]);
											
									}
																							
																				}
																				
																				destFolder = mySubFolder;
																				destName = split[1];
								
																	} else if(split.length==3) {
								
								myFolder = _myDestFolder;
																				if(mySubFolder==null) {
									
									tempFile = null;
									tempFile = DocumentFile.fromSingleUri(this, Uri.parse(myFolder.getUri().toString().concat(Uri.encode("/").concat(split[0]))));
									
									
									
									if (tempFile.exists()) {
										
										mySubFolder = tempFile;
										
										
											
									}else {
										mySubFolder = myFolder.createDirectory(split[0]);
											
									}
																							
																				}
																				if(mySubSubFolder==null) {
									tempFile = null;
									tempFile = DocumentFile.fromSingleUri(this, Uri.parse(mySubFolder.getUri().toString().concat(Uri.encode("/").concat(split[1]))));
									
									
									
									if (tempFile.exists()) {
										
										mySubSubFolder = tempFile;
										
										
											
									}else {
										mySubSubFolder = mySubFolder.createDirectory(split[1]);
											
									}
																							
																				}
																				
																				destFolder = mySubSubFolder;
																				destName = split[2];
																	}
							else if(split.length==4) {
								
								myFolder = _myDestFolder;
																				if(mySubFolder==null) {
									
									tempFile = null;
									tempFile = DocumentFile.fromSingleUri(this, Uri.parse(myFolder.getUri().toString().concat(Uri.encode("/").concat(split[0]))));
									
									
									
									if (tempFile.exists()) {
										
										mySubFolder = tempFile;
										
										
											
									}else {
										mySubFolder = myFolder.createDirectory(split[0]);
											
									}
																							
																				}
																				if(mySubSubFolder==null) {
									tempFile = null;
									tempFile = DocumentFile.fromSingleUri(this, Uri.parse(mySubFolder.getUri().toString().concat(Uri.encode("/").concat(split[1]))));
									
									
									
									if (tempFile.exists()) {
										
										mySubSubFolder = tempFile;
										
										
											
									}else {
										mySubSubFolder = mySubFolder.createDirectory(split[1]);
											
									}
																							
																				}
								if(mySubSubSubFolder==null) {
									tempFile = null;
									tempFile = DocumentFile.fromSingleUri(this, Uri.parse(mySubSubFolder.getUri().toString().concat(Uri.encode("/").concat(split[2]))));
									
									
									
									if (tempFile.exists()) {
										
										mySubSubSubFolder = tempFile;
										
										
											
									}else {
										mySubSubSubFolder = mySubSubFolder.createDirectory(split[2]);
											
									}
																							
																				}
																				
																				destFolder = mySubSubSubFolder;
																				destName = split[3];
																	}
							else if(split.length==5) {
								
								myFolder = _myDestFolder;
																				if(mySubFolder==null) {
									
									tempFile = null;
									tempFile = DocumentFile.fromSingleUri(this, Uri.parse(myFolder.getUri().toString().concat(Uri.encode("/").concat(split[0]))));
									
									
									
									if (tempFile.exists()) {
										
										mySubFolder = tempFile;
										
										
											
									}else {
										mySubFolder = myFolder.createDirectory(split[0]);
											
									}
																							
																				}
																				if(mySubSubFolder==null) {
									tempFile = null;
									tempFile = DocumentFile.fromSingleUri(this, Uri.parse(mySubFolder.getUri().toString().concat(Uri.encode("/").concat(split[1]))));
									
									
									
									if (tempFile.exists()) {
										
										mySubSubFolder = tempFile;
										
										
											
									}else {
										mySubSubFolder = mySubFolder.createDirectory(split[1]);
											
									}
																							
																				}
								if(mySubSubSubFolder==null) {
									tempFile = null;
									tempFile = DocumentFile.fromSingleUri(this, Uri.parse(mySubSubFolder.getUri().toString().concat(Uri.encode("/").concat(split[2]))));
									
									
									
									if (tempFile.exists()) {
										
										mySubSubSubFolder = tempFile;
										
										
											
									}else {
										mySubSubSubFolder = mySubSubFolder.createDirectory(split[2]);
											
									}
																							
																				}
													
								if(mySubSubSubSubFolder==null) {
									tempFile = null;
									tempFile = DocumentFile.fromSingleUri(this, Uri.parse(mySubSubSubFolder.getUri().toString().concat(Uri.encode("/").concat(split[3]))));
									
									
									
									if (tempFile.exists()) {
										
										mySubSubSubSubFolder = tempFile;
										
										
											
									}else {
										mySubSubSubSubFolder = mySubSubSubFolder.createDirectory(split[3]);
											
									}
																							
																				}
																				
																				destFolder = mySubSubSubSubFolder;
																				destName = split[4];
																	}
																	
																	
														}
						
						
						if (!zipEntry.isDirectory()) {
							
															DocumentFile df = null;
															
															//Now you have to tell it what file extensions ("MIME" type) you want to use, e.g.:
							
							tempFile = null;
							tempFile = DocumentFile.fromSingleUri(this, Uri.parse(destFolder.getUri().toString().concat(Uri.encode("/").concat(destName))));
							
							
							if (tempFile.exists()) {
								
								df = tempFile;
								
								
									
							}else {
								df = destFolder.createFile("*/*",destName);
									
							}
															
															
															OutputStream out = getContentResolver().openOutputStream(df.getUri());
															BufferedOutputStream bos = new BufferedOutputStream(out);
															long zipfilesize = zipEntry.getSize();
															
															byte[] buffer = new byte[10000];
															int len = 0;
															int totlen = 0;
															
															while (((len = zis.read(buffer, 0, 10000)) > 0) ) {
																		bos.write(buffer, 0, len);
																		totlen += len;
															}
							
															
															bos.close();
						}
											} catch (IOException e1) {
														
												SketchwareUtil.showMessage(getApplicationContext(), e1.getMessage());		
														
														return false;
											}
								}
								
								is.close();
								bis.close();
								zis.close();
					} catch (IOException e2) {
				SketchwareUtil.showMessage(getApplicationContext(), e2.getMessage());
				
								return false;
					}
					
		} catch(Exception e){
			SketchwareUtil.showMessage(getApplicationContext(), e.getMessage());
					return false;
		}		           
		return true;
	}
	Boolean unzipAssets(String _filename, DocumentFile _myDestFolder) {
		
			  DocumentFile myFolder = null;
			  DocumentFile mySubFolder = null;
			 DocumentFile mySubSubFolder = null;
		DocumentFile tempFile = null;
		
		try {
					try{
								InputStream is = this.getAssets().open(_filename);
								BufferedInputStream bis = new BufferedInputStream(is);
								ZipInputStream zis = new ZipInputStream(bis);
								ZipEntry zipEntry;
								
								while ((zipEntry = zis.getNextEntry()) != null) {
											String fileName = null; 
											
											try {
														fileName = zipEntry.getName();        
														fileName = fileName.replace("\\",File.separator).replace("/",File.separator);
														int p=fileName.lastIndexOf(File.separator);        
														DocumentFile destFolder = _myDestFolder;
							                     //DocumentFile of the destination folder
														String destName = fileName;
														
														if (p>=0) {
																	String[] split = fileName.split(File.separator);
																	
																	//If the .zip file contains multiple folder levels, this is where you  
																	//have to check and then create them, e.g. for 3 levels:
																	
																	
																	
																	if(split.length==1) {
								if(myFolder==null) {
																							myFolder = _myDestFolder;
									
																				}
																				destFolder = myFolder;
																				destName = fileName;
																	} else if(split.length==2) {
								myFolder = _myDestFolder;
																				if(mySubFolder==null) {
									tempFile = null;
									tempFile = DocumentFile.fromSingleUri(this, Uri.parse(myFolder.getUri().toString().concat(Uri.encode("/").concat(split[0]))));
									
									
									
									if (tempFile.exists()) {
										
										mySubFolder = tempFile;
										
										
											
									}else {
										mySubFolder = myFolder.createDirectory(split[0]);
											
									}
																							
																				}
																				
																				destFolder = mySubFolder;
																				destName = split[1];
								
																	} else if(split.length==3) {
								
								myFolder = _myDestFolder;
																				if(mySubFolder==null) {
									
									tempFile = null;
									tempFile = DocumentFile.fromSingleUri(this, Uri.parse(myFolder.getUri().toString().concat(Uri.encode("/").concat(split[0]))));
									
									
									
									if (tempFile.exists()) {
										
										mySubFolder = tempFile;
										
										
											
									}else {
										mySubFolder = myFolder.createDirectory(split[0]);
											
									}
																							
																				}
																				if(mySubSubFolder==null) {
									tempFile = null;
									tempFile = DocumentFile.fromSingleUri(this, Uri.parse(mySubFolder.getUri().toString().concat(Uri.encode("/").concat(split[1]))));
									
									
									
									if (tempFile.exists()) {
										
										mySubSubFolder = tempFile;
										
										
											
									}else {
										mySubSubFolder = mySubFolder.createDirectory(split[1]);
											
									}
																							
																				}
																				
																				destFolder = mySubSubFolder;
																				destName = split[2];
																	}
																	
																	
														}
						
						
						if (!zipEntry.isDirectory()) {
							
															DocumentFile df = null;
															
															//Now you have to tell it what file extensions ("MIME" type) you want to use, e.g.:
							
							tempFile = null;
							tempFile = DocumentFile.fromSingleUri(this, Uri.parse(destFolder.getUri().toString().concat(Uri.encode("/").concat(destName))));
							
							
							if (tempFile.exists()) {
								
								df = tempFile;
								
								
									
							}else {
								df = destFolder.createFile("*/*",destName);
									
							}
															
															
															OutputStream out = getContentResolver().openOutputStream(df.getUri());
															BufferedOutputStream bos = new BufferedOutputStream(out);
															long zipfilesize = zipEntry.getSize();
															
															byte[] buffer = new byte[10000];
															int len = 0;
															int totlen = 0;
															
															while (((len = zis.read(buffer, 0, 10000)) > 0) ) {
																		bos.write(buffer, 0, len);
																		totlen += len;
															}
							
															
															bos.close();
						}
											} catch (IOException e1) {
														
												SketchwareUtil.showMessage(getApplicationContext(), e1.getMessage());		
														
														return false;
											}
								}
								
								is.close();
								bis.close();
								zis.close();
					} catch (IOException e2) {
				SketchwareUtil.showMessage(getApplicationContext(), e2.getMessage());
				
								return false;
					}
					
		} catch(Exception e){
			SketchwareUtil.showMessage(getApplicationContext(), e.getMessage());
					return false;
		}		           
		return true;
	}
	{
	}
	
	
	public void _refresh() {
		try {
			listview1.setAdapter(new Listview1Adapter(listmap));
			((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
		} catch (Exception e) {
			 
		}
	}
	
	
	public void _unzip(final Uri _uri, final Uri _folderUri) {
		    mfile = DocumentFile.fromTreeUri(this, _folderUri);
		                    
		if (unzip (_uri, mfile)) {
			SketchwareUtil.showMessage(getApplicationContext(), "Success");
			listmap.clear();
			if (currentLoc.length() > 0) {
				if (updateDirectoryEntries(parenturi, currentLoc)) {
					_refresh();
				}
			}
			else {
				if (updateDirectoryEntries(parenturi)) {
					_refresh();
				}
			}
		}
		else {
			SketchwareUtil.showMessage(getApplicationContext(), "Failed");
		}
	}
	
	
	public void _unzipAssets(final String _filename, final Uri _folderUri) {
		    mfile = DocumentFile.fromTreeUri(this, _folderUri);
		                    
		if (unzipAssets (_filename, mfile)) {
			SketchwareUtil.showMessage(getApplicationContext(), "Success");
			listmap.clear();
			if (currentLoc.length() > 0) {
				if (updateDirectoryEntries(parenturi, currentLoc)) {
					_refresh();
				}
			}
			else {
				if (updateDirectoryEntries(parenturi)) {
					_refresh();
				}
			}
		}
		else {
			SketchwareUtil.showMessage(getApplicationContext(), "Failed");
		}
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.files_c, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			imageview1.setColorFilter(0xFFFDD835, PorterDuff.Mode.MULTIPLY);
			try {
				textview1.setText(_data.get((int)_position).get("name").toString());
			} catch (Exception e) {
				 
			}
			if (isDirectory(_data.get((int)_position).get("mime").toString())) {
				imageview1.setImageResource(R.drawable.ic_folder_white);
				linear1.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (currentLoc.length() > 0) {
							lastLoc = currentLoc;
						}
						else {
							lastLoc = "";
						}
						currentLoc = _data.get((int)_position).get("docId").toString();
						listmap.clear();
						if (updateDirectoryEntries(parenturi, currentLoc)) {
							_refresh();
						}
					}
				});
			}
			else {
				imageview1.setImageResource(R.drawable.ic_description_white);
				linear1.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						muri = Uri.parse(sp.getString("FOLDER_URI", "").concat("/document/".concat(_data.get((int)_position).get("docId").toString().replace(":", "%3A").replace("/", "%2F"))));
						if (currentLoc.length() > 0) {
							uri2 = Uri.parse(sp.getString("FOLDER_URI", "").concat("/document/".concat(currentLoc.replace(":", "%3A").replace("/", "%2F"))));
						}
						else {
							uri2 = Uri.parse(sp.getString("DIRECT_FOLDER_URI", ""));
						}
						_unzip(muri, uri2);
					}
				});
			}
			linear1.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View _view) {
					dlg.setTitle("Delete?");
					dlg.setMessage("Do you want to delete ".concat(_data.get((int)_position).get("name").toString().concat(" ?")));
					dlg.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							uri2 = Uri.parse(sp.getString("FOLDER_URI", "").concat("/document/".concat(_data.get((int)_position).get("docId").toString().replace(":", "%3A").replace("/", "%2F"))));
							try {
								try{
									        DocumentsContract.deleteDocument(getApplicationContext().getContentResolver(), uri2);
									    SketchwareUtil.showMessage(getApplicationContext(), "File deleted");
									listmap.clear();
									if (currentLoc.length() > 0) {
										if (updateDirectoryEntries(parenturi, currentLoc)) {
											_refresh();
										}
									}
									else {
										if (updateDirectoryEntries(parenturi)) {
											_refresh();
										}
									}
									        } catch (FileNotFoundException e) {
									        SketchwareUtil.showMessage(getApplicationContext(), "file does not exist");
									    }             
							} catch (Exception e) {
								SketchwareUtil.showMessage(getApplicationContext(), e.getMessage());
							}
						}
					});
					dlg.setNegativeButton("No", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					dlg.create().show();
					return true;
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}