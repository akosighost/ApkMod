package com.zinexus.domain;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.azoft.carousellayoutmanager.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.bumptech.glide.Glide;
import com.downloader.*;
import com.google.firebase.FirebaseApp;
import com.kaopiz.kprogresshud.*;
import com.twotoasters.jazzylistview.*;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import jp.wasabeef.picasso.transformations.*;
import me.everything.*;
import org.json.*;
import java.io.*;
import java.util.zip.*;
import androidx.documentfile.provider.DocumentFile;
import android.provider.DocumentsContract;
import android.database.*;
import android.provider.DocumentsContract.Document;

public class AutoinjectActivity extends AppCompatActivity {
	
	private String release = "";
	private HashMap<String, Object> map_listview1 = new HashMap<>();
	private double size = 0;
	private double sumCount = 0;
	private String file = "";
	private String filename = "";
	private  Uri muri;
	private  Uri suri;
	private  Uri urit;
	private  DocumentFile file1;
	private  DocumentFile file2;
	private  DocumentFile f3;
	private  DocumentFile f4;
	private  DocumentFile filepath;
	private  DocumentFile path;
	private  DocumentFile path1;
	private  static final int NEW_FOLDER_REQUEST_CODE = 43;
	private  Runnable runnable;
	private  Uri uri1;
	private  Dialog dialog;
	private  DocumentFile mfile;
	private  Uri uri2;
	private  DocumentFile mfile1;
	private HashMap<String, Object> map_report = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> listmap_listview1 = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear9;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private TextView textview1;
	private LinearLayout linear8;
	private TextView textview2;
	private LinearLayout linear10;
	private LinearLayout linear13;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private TextView textview5;
	private LinearLayout linear14;
	private LinearLayout linear16;
	private TextView textview4;
	private JazzyListView listview1;
	private LinearLayout linear15;
	private CardView card;
	private ImageView image;
	private LinearLayout container;
	private LinearLayout linear17;
	private CircleImageView circleimageview1;
	private LinearLayout linear19;
	private LinearLayout linear18;
	private TextView textview3;
	
	private Intent intent = new Intent();
	private SharedPreferences save;
	private  CustomToast;
	private  CustomDialog;
	private RequestNetwork internet;
	private RequestNetwork.RequestListener _internet_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.autoinject);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear9 = findViewById(R.id.linear9);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		textview1 = findViewById(R.id.textview1);
		linear8 = findViewById(R.id.linear8);
		textview2 = findViewById(R.id.textview2);
		linear10 = findViewById(R.id.linear10);
		linear13 = findViewById(R.id.linear13);
		linear11 = findViewById(R.id.linear11);
		linear12 = findViewById(R.id.linear12);
		textview5 = findViewById(R.id.textview5);
		linear14 = findViewById(R.id.linear14);
		linear16 = findViewById(R.id.linear16);
		textview4 = findViewById(R.id.textview4);
		listview1 = findViewById(R.id.listview1);
		linear15 = findViewById(R.id.linear15);
		card = findViewById(R.id.card);
		image = findViewById(R.id.image);
		container = findViewById(R.id.container);
		linear17 = findViewById(R.id.linear17);
		circleimageview1 = findViewById(R.id.circleimageview1);
		linear19 = findViewById(R.id.linear19);
		linear18 = findViewById(R.id.linear18);
		textview3 = findViewById(R.id.textview3);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		internet = new RequestNetwork(this);
		
		linear18.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (SketchwareUtil.isConnected(getApplicationContext())) {
					_Backup();
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Please check your internet connection");
				}
			}
		});
		
		_internet_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		_SetStatusBarColor("#0B141D", "#0B141D");
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF121F2B);
			SketchUi.setCornerRadius(d*12);
			linear3.setElevation(d*5);
			linear3.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF121F2B);SketchUi.setCornerRadii(new float[]{
				d*0,d*0,d*0 ,d*0,d*25,d*25 ,d*25,d*25});
			linear12.setElevation(d*5);
			linear12.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF121F2B);SketchUi.setCornerRadii(new float[]{
				d*25,d*25,d*25 ,d*25,d*0,d*0 ,d*0,d*0});
			linear13.setElevation(d*5);
			linear13.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF0B141A);
			SketchUi.setCornerRadius(d*10);
			linear15.setElevation(d*5);
			linear15.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF101010);
			SketchUi.setCornerRadius(d*5);
			linear18.setElevation(d*5);
			android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF9E9E9E}), SketchUi, null);
			linear18.setBackground(SketchUiRD);
			linear18.setClickable(true);
		}
		listview1.setHorizontalScrollBarEnabled(false);
		listview1.setVerticalScrollBarEnabled(false);
		listview1.setOverScrollMode(ListView.OVER_SCROLL_NEVER);
		listview1.setDivider(null);listview1.setDividerHeight(0);
		listview1.setSelector(android.R.color.transparent);
		((ViewGroup) image.getParent()).removeView(image);
		((ViewGroup) container.getParent()).removeView(container);
		android.widget.RelativeLayout rl = new android.widget.RelativeLayout(AutoinjectActivity.this);
		
		rl.setLayoutParams(new LinearLayout.LayoutParams(-1,-1));
		
		card.removeAllViews();
		
		card.addView(rl);
		
		rl.addView(image);
		
		rl.addView(container);
		release = Build.VERSION.RELEASE;
		textview2.setText("Android ".concat(release));
		textview5.setEllipsize(TextUtils.TruncateAt.MARQUEE); textview5.setText("Please wait for the images to load to avoid any errors."); textview5.setSelected(true); textview5.setSingleLine(true);
		card.setCardBackgroundColor(Color.TRANSPARENT);
		card.setRadius((float)15);
		if (getIntent().hasExtra("landscape")) {
			Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("landscape"))).into(image);
		}
		if (getIntent().hasExtra("url")) {
			Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("url"))).into(circleimageview1);
		}
		if (getIntent().hasExtra("name")) {
			textview1.setText(getIntent().getStringExtra("name"));
		}
		if (getIntent().hasExtra("number")) {
			textview4.setText(getIntent().getStringExtra("number").concat(" Available Skin's"));
		}
		listview1.setTransitionEffect(new com.twotoasters.jazzylistview.effects.SlideInEffect());
		_Api();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		    if (_data != null) {
				               muri = _data.getData();
				if (Uri.decode(muri.toString()).endsWith(":")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Can't use root folder please choose another");
						_AskPermission(linear1);
				}
				else {
						final int takeFlags = intent.getFlags()
						            & (Intent.FLAG_GRANT_READ_URI_PERMISSION
						            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
						// Check for the freshest data.
						getContentResolver().takePersistableUriPermission(muri, takeFlags);
						save.edit().putString("FOLDER_URI", muri.toString()).commit();
						    mfile = DocumentFile.fromTreeUri(this, muri);
						                    
						    mfile1 = mfile.createFile("*/*", "test.file");
						    uri2 = mfile1.getUri();
						save.edit().putString("DIRECT_FOLDER_URI", uri2.toString().substring((int)(0), (int)(uri2.toString().length() - 9))).commit();
						try{
								        DocumentsContract.deleteDocument(getApplicationContext().getContentResolver(), uri2);
								     
								        } catch (FileNotFoundException e) {
								         
								    }             
				}
				       } else {
				        
				   }
		    if (_resultCode == Activity.RESULT_OK) {
				        CustomDialog.dismiss();
				SketchwareUtil.showMessage(getApplicationContext(), "Permission Granted");
				       } else {
				       CustomDialog.dismiss();
				SketchwareUtil.showMessage(getApplicationContext(), "Permission Denied");
				   }
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	
	@Override
	public void onBackPressed() {
		intent.setClass(getApplicationContext(), ListcategoryActivity.class);
		intent.putExtra("category", getIntent().getStringExtra("Category"));
		intent.putExtra("list", getIntent().getStringExtra("List"));
		startActivity(intent);
		overridePendingTransition(R.anim.fin, R.anim.fout);
	}
	public void _SetStatusBarColor(final String _color1, final String _color2) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) { 
			   Window w = this.getWindow(); w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS); w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			   w.setStatusBarColor(Color.parseColor(_color1)); w.setNavigationBarColor(Color.parseColor(_color2));
		}
	}
	
	
	public void _Api() {
		if (getIntent().hasExtra("skin1")) {
			map_listview1 = new HashMap<>();
			map_listview1.put("img1", getIntent().getStringExtra("skin1"));
			map_listview1.put("img2", getIntent().getStringExtra("logo1"));
			if (getIntent().hasExtra("name1")) {
				map_listview1.put("txt1", getIntent().getStringExtra("name1"));
			}
			if (getIntent().hasExtra("script1")) {
				map_listview1.put("inject", getIntent().getStringExtra("script1"));
			}
			listmap_listview1.add(map_listview1);
		}
		if (getIntent().hasExtra("skin2")) {
			map_listview1 = new HashMap<>();
			map_listview1.put("img1", getIntent().getStringExtra("skin2"));
			map_listview1.put("img2", getIntent().getStringExtra("logo2"));
			if (getIntent().hasExtra("name2")) {
				map_listview1.put("txt1", getIntent().getStringExtra("name2"));
			}
			if (getIntent().hasExtra("script2")) {
				map_listview1.put("inject", getIntent().getStringExtra("script2"));
			}
			listmap_listview1.add(map_listview1);
		}
		if (getIntent().hasExtra("skin3")) {
			map_listview1 = new HashMap<>();
			map_listview1.put("img1", getIntent().getStringExtra("skin3"));
			map_listview1.put("img2", getIntent().getStringExtra("logo3"));
			if (getIntent().hasExtra("name3")) {
				map_listview1.put("txt1", getIntent().getStringExtra("name3"));
			}
			if (getIntent().hasExtra("script3")) {
				map_listview1.put("inject", getIntent().getStringExtra("script3"));
			}
			listmap_listview1.add(map_listview1);
		}
		if (getIntent().hasExtra("skin4")) {
			map_listview1 = new HashMap<>();
			map_listview1.put("img1", getIntent().getStringExtra("skin4"));
			map_listview1.put("img2", getIntent().getStringExtra("logo4"));
			if (getIntent().hasExtra("name4")) {
				map_listview1.put("txt1", getIntent().getStringExtra("name4"));
			}
			if (getIntent().hasExtra("script4")) {
				map_listview1.put("inject", getIntent().getStringExtra("script4"));
			}
			listmap_listview1.add(map_listview1);
		}
		if (getIntent().hasExtra("skin5")) {
			map_listview1 = new HashMap<>();
			map_listview1.put("img1", getIntent().getStringExtra("skin5"));
			map_listview1.put("img2", getIntent().getStringExtra("logo5"));
			if (getIntent().hasExtra("name5")) {
				map_listview1.put("txt1", getIntent().getStringExtra("name5"));
			}
			if (getIntent().hasExtra("script5")) {
				map_listview1.put("inject", getIntent().getStringExtra("script5"));
			}
			listmap_listview1.add(map_listview1);
		}
		if (getIntent().hasExtra("skin6")) {
			map_listview1 = new HashMap<>();
			map_listview1.put("img1", getIntent().getStringExtra("skin6"));
			map_listview1.put("img2", getIntent().getStringExtra("logo6"));
			if (getIntent().hasExtra("name6")) {
				map_listview1.put("txt1", getIntent().getStringExtra("name6"));
			}
			if (getIntent().hasExtra("script6")) {
				map_listview1.put("inject", getIntent().getStringExtra("script6"));
			}
			listmap_listview1.add(map_listview1);
		}
		if (getIntent().hasExtra("skin7")) {
			map_listview1 = new HashMap<>();
			map_listview1.put("img1", getIntent().getStringExtra("skin7"));
			map_listview1.put("img2", getIntent().getStringExtra("logo7"));
			if (getIntent().hasExtra("name7")) {
				map_listview1.put("txt1", getIntent().getStringExtra("name7"));
			}
			if (getIntent().hasExtra("script7")) {
				map_listview1.put("inject", getIntent().getStringExtra("script7"));
			}
			listmap_listview1.add(map_listview1);
		}
		if (getIntent().hasExtra("skin8")) {
			map_listview1 = new HashMap<>();
			map_listview1.put("img1", getIntent().getStringExtra("skin8"));
			map_listview1.put("img2", getIntent().getStringExtra("logo8"));
			if (getIntent().hasExtra("name8")) {
				map_listview1.put("txt1", getIntent().getStringExtra("name8"));
			}
			if (getIntent().hasExtra("script8")) {
				map_listview1.put("inject", getIntent().getStringExtra("script8"));
			}
			listmap_listview1.add(map_listview1);
		}
		if (getIntent().hasExtra("skin9")) {
			map_listview1 = new HashMap<>();
			map_listview1.put("img1", getIntent().getStringExtra("skin9"));
			map_listview1.put("img2", getIntent().getStringExtra("logo9"));
			if (getIntent().hasExtra("name9")) {
				map_listview1.put("txt1", getIntent().getStringExtra("name9"));
			}
			if (getIntent().hasExtra("script9")) {
				map_listview1.put("inject", getIntent().getStringExtra("script9"));
			}
			listmap_listview1.add(map_listview1);
		}
		if (getIntent().hasExtra("skin10")) {
			map_listview1 = new HashMap<>();
			map_listview1.put("img1", getIntent().getStringExtra("skin10"));
			map_listview1.put("img2", getIntent().getStringExtra("logo10"));
			if (getIntent().hasExtra("name10")) {
				map_listview1.put("txt1", getIntent().getStringExtra("name10"));
			}
			if (getIntent().hasExtra("script10")) {
				map_listview1.put("inject", getIntent().getStringExtra("script10"));
			}
			listmap_listview1.add(map_listview1);
		}
		listview1.setAdapter(new Listview1Adapter(listmap_listview1));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	
	public void _Adapter(final ImageView _imageview, final double _position, final ArrayList<HashMap<String, Object>> _data) {
		
		if (_data.get((int)_position).get("img2").toString().equals("Normal")) {
			Glide.with(getApplicationContext())
			.load("https://github.com/akosighost/Logo-image/raw/main/transparent.png")
			.placeholder(R.drawable.transparent)
			.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
			.into(_imageview);
		}
		else {
			if (_data.get((int)_position).get("img2").toString().equals("Seasonal")) {
				Glide.with(getApplicationContext())
				.load("https://github.com/akosighost/Logo-image/raw/main/transparent.png")
				.placeholder(R.drawable.transparent)
				.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
				.into(_imageview);
			}
			else {
				if (_data.get((int)_position).get("img2").toString().equals("M - World")) {
					Glide.with(getApplicationContext())
					.load("https://github.com/akosighost/Logo-image/raw/main/M-World_Skin_Tag.png")
					.placeholder(R.drawable.transparent)
					.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
					.into(_imageview);
				}
				else {
					if (_data.get((int)_position).get("img2").toString().equals("Annual")) {
						Glide.with(getApplicationContext())
						.load("https://github.com/akosighost/Logo-image/raw/main/annual_starlight_skin_tag.png")
						.placeholder(R.drawable.transparent)
						.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
						.into(_imageview);
					}
					else {
						if (_data.get((int)_position).get("img2").toString().equals("Collector")) {
							Glide.with(getApplicationContext())
							.load("https://github.com/akosighost/Logo-image/raw/main/collector_skin_tag.png")
							.placeholder(R.drawable.transparent)
							.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
							.into(_imageview);
						}
						else {
							if (_data.get((int)_position).get("img2").toString().equals("Elite")) {
								Glide.with(getApplicationContext())
								.load("https://github.com/akosighost/Logo-image/raw/main/elite_skin_tag.png")
								.placeholder(R.drawable.transparent)
								.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
								.into(_imageview);
							}
							else {
								if (_data.get((int)_position).get("img2").toString().equals("Epic")) {
									Glide.with(getApplicationContext())
									.load("https://github.com/akosighost/Logo-image/raw/main/epic_skin_tag.png")
									.placeholder(R.drawable.transparent)
									.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
									.into(_imageview);
								}
								else {
									if (_data.get((int)_position).get("img2").toString().equals("515")) {
										Glide.with(getApplicationContext())
										.load("https://github.com/akosighost/Logo-image/raw/main/five_one_five_skin_tag.png")
										.placeholder(R.drawable.transparent)
										.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
										.into(_imageview);
									}
									else {
										if (_data.get((int)_position).get("img2").toString().equals("Hero")) {
											Glide.with(getApplicationContext())
											.load("https://github.com/akosighost/Logo-image/raw/main/hero_skin_tag.png")
											.placeholder(R.drawable.transparent)
											.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
											.into(_imageview);
										}
										else {
											if (_data.get((int)_position).get("img2").toString().equals("Kof")) {
												Glide.with(getApplicationContext())
												.load("https://github.com/akosighost/Logo-image/raw/main/kof_skin_tag.png")
												.placeholder(R.drawable.transparent)
												.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
												.into(_imageview);
											}
											else {
												if (_data.get((int)_position).get("img2").toString().equals("Legend")) {
													Glide.with(getApplicationContext())
													.load("https://github.com/akosighost/Logo-image/raw/main/legend_skin_tag.png")
													.placeholder(R.drawable.transparent)
													.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
													.into(_imageview);
												}
												else {
													if (_data.get((int)_position).get("img2").toString().equals("Lightborn")) {
														Glide.with(getApplicationContext())
														.load("https://github.com/akosighost/Logo-image/raw/main/lightborn_skin_tag.png")
														.placeholder(R.drawable.transparent)
														.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
														.into(_imageview);
													}
													else {
														if (_data.get((int)_position).get("img2").toString().equals("Limited")) {
															Glide.with(getApplicationContext())
															.load("https://github.com/akosighost/Logo-image/raw/main/limited_skin_tag.png")
															.placeholder(R.drawable.transparent)
															.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
															.into(_imageview);
														}
														else {
															if (_data.get((int)_position).get("img2").toString().equals("Mpl")) {
																Glide.with(getApplicationContext())
																.load("https://github.com/akosighost/Logo-image/raw/main/mpl_skin_tag.png")
																.placeholder(R.drawable.transparent)
																.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																.into(_imageview);
															}
															else {
																if (_data.get((int)_position).get("img2").toString().equals("Pacquiao")) {
																	Glide.with(getApplicationContext())
																	.load("https://github.com/akosighost/Logo-image/raw/main/pacquiao_skin_tag.png")
																	.placeholder(R.drawable.transparent)
																	.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																	.into(_imageview);
																}
																else {
																	if (_data.get((int)_position).get("img2").toString().equals("Special")) {
																		Glide.with(getApplicationContext())
																		.load("https://github.com/akosighost/Logo-image/raw/main/special_skin_tag.png")
																		.placeholder(R.drawable.transparent)
																		.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																		.into(_imageview);
																	}
																	else {
																		if (_data.get((int)_position).get("img2").toString().equals("Starlight")) {
																			Glide.with(getApplicationContext())
																			.load("https://github.com/akosighost/Logo-image/raw/main/starlight_skin_tag.png")
																			.placeholder(R.drawable.transparent)
																			.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																			.into(_imageview);
																		}
																		else {
																			if (_data.get((int)_position).get("img2").toString().equals("Starwars")) {
																				Glide.with(getApplicationContext())
																				.load("https://github.com/akosighost/Logo-image/raw/main/starwars_skin_tag.png")
																				.placeholder(R.drawable.transparent)
																				.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																				.into(_imageview);
																			}
																			else {
																				if (_data.get((int)_position).get("img2").toString().equals("Stun")) {
																					Glide.with(getApplicationContext())
																					.load("https://github.com/akosighost/Logo-image/raw/main/stun_skin_tag.png")
																					.placeholder(R.drawable.transparent)
																					.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																					.into(_imageview);
																				}
																				else {
																					if (_data.get((int)_position).get("img2").toString().equals("Summer")) {
																						Glide.with(getApplicationContext())
																						.load("https://github.com/akosighost/Logo-image/raw/main/summer_skin_tag.png")
																						.placeholder(R.drawable.transparent)
																						.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																						.into(_imageview);
																					}
																					else {
																						if (_data.get((int)_position).get("img2").toString().equals("Transformers")) {
																							Glide.with(getApplicationContext())
																							.load("https://github.com/akosighost/Logo-image/raw/main/transformers_skin_tag.png")
																							.placeholder(R.drawable.transparent)
																							.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																							.into(_imageview);
																						}
																						else {
																							if (_data.get((int)_position).get("img2").toString().equals("Zodiac")) {
																								Glide.with(getApplicationContext())
																								.load("https://github.com/akosighost/Logo-image/raw/main/zodiac_skin_tag.png")
																								.placeholder(R.drawable.transparent)
																								.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																								.into(_imageview);
																							}
																							else {
																								if (_data.get((int)_position).get("img2").toString().equals("Sanrio")) {
																									Glide.with(getApplicationContext())
																									.load("https://github.com/akosighost/Logo-image/raw/main/sanrio_skin_tag.png")
																									.placeholder(R.drawable.transparent)
																									.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																									.into(_imageview);
																								}
																								else {
																									if (_data.get((int)_position).get("img2").toString().equals("11.11")) {
																										Glide.with(getApplicationContext())
																										.load("https://github.com/akosighost/Logo-image/raw/main/11.11_skin_tag.png")
																										.placeholder(R.drawable.transparent)
																										.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																										.into(_imageview);
																									}
																									else {
																										if (_data.get((int)_position).get("img2").toString().equals("Abyss")) {
																											Glide.with(getApplicationContext())
																											.load("https://github.com/akosighost/Logo-image/raw/main/abyss_skin_tag.png")
																											.placeholder(R.drawable.transparent)
																											.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																											.into(_imageview);
																										}
																										else {
																											if (_data.get((int)_position).get("img2").toString().equals("Aspirant")) {
																												Glide.with(getApplicationContext())
																												.load("https://github.com/akosighost/Logo-image/raw/main/aspirants_skin_tag.png")
																												.placeholder(R.drawable.transparent)
																												.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																												.into(_imageview);
																											}
																											else {
																												if (_data.get((int)_position).get("img2").toString().equals("Christmas")) {
																													Glide.with(getApplicationContext())
																													.load("https://github.com/akosighost/Logo-image/raw/main/christmas_skin_tag.png")
																													.placeholder(R.drawable.transparent)
																													.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																													.into(_imageview);
																												}
																												else {
																													if (_data.get((int)_position).get("img2").toString().equals("Halloween")) {
																														Glide.with(getApplicationContext())
																														.load("https://github.com/akosighost/Logo-image/raw/main/halloween_skin_tag.png")
																														.placeholder(R.drawable.transparent)
																														.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																														.into(_imageview);
																													}
																													else {
																														if (_data.get((int)_position).get("img2").toString().equals("Valentine")) {
																															Glide.with(getApplicationContext())
																															.load("https://github.com/akosighost/Logo-image/raw/main/valentine_skin_tag.png")
																															.placeholder(R.drawable.transparent)
																															.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																															.into(_imageview);
																														}
																														else {
																															if (_data.get((int)_position).get("img2").toString().equals("M1")) {
																																Glide.with(getApplicationContext())
																																.load("https://github.com/akosighost/Logo-image/raw/main/M1_Skin_Tag.png")
																																.placeholder(R.drawable.transparent)
																																.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																																.into(_imageview);
																															}
																															else {
																																if (_data.get((int)_position).get("img2").toString().equals("M2")) {
																																	Glide.with(getApplicationContext())
																																	.load("https://github.com/akosighost/Logo-image/raw/main/M2_Skin_Tag.png")
																																	.placeholder(R.drawable.transparent)
																																	.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																																	.into(_imageview);
																																}
																																else {
																																	if (_data.get((int)_position).get("img2").toString().equals("M3")) {
																																		Glide.with(getApplicationContext())
																																		.load("https://github.com/akosighost/Logo-image/raw/main/M3_Skin_Tag.png")
																																		.placeholder(R.drawable.transparent)
																																		.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																																		.into(_imageview);
																																	}
																																	else {
																																		if (_data.get((int)_position).get("img2").toString().equals("Anniversary")) {
																																			Glide.with(getApplicationContext())
																																			.load("https://github.com/akosighost/Logo-image/raw/main/5th_Anniversary_Skin_Tag.png")
																																			.placeholder(R.drawable.transparent)
																																			.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																																			.into(_imageview);
																																		}
																																		else {
																																			if (_data.get((int)_position).get("img2").toString().equals("Prime")) {
																																				Glide.with(getApplicationContext())
																																				.load("https://github.com/akosighost/Logo-image/raw/main/PRIME_Skin_Tag.png")
																																				.placeholder(R.drawable.transparent)
																																				.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																																				.into(_imageview);
																																			}
																																			else {
																																				if (_data.get((int)_position).get("img2").toString().equals("Msc")) {
																																					Glide.with(getApplicationContext())
																																					.load("https://github.com/akosighost/Logo-image/raw/main/special_skin_tag.png")
																																					.placeholder(R.drawable.transparent)
																																					.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																																					.into(_imageview);
																																				}
																																				else {
																																					Glide.with(getApplicationContext())
																																					.load("https://github.com/akosighost/Logo-image/raw/main/transparent.png")
																																					.placeholder(R.drawable.transparent)
																																					.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)1))
																																					.into(_imageview);
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	
	public void _inject() {
	}
	private class Auto11 extends AsyncTask<String, Integer, String> {
		KProgressHUD hud;
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			hud = new KProgressHUD(AutoinjectActivity.this).setStyle(KProgressHUD.Style.ANNULAR_DETERMINATE).setLabel("Please Wait..")
			.setMaxProgress(100);
			 
			hud.show();
			
		}
		String filename = "";
		String result = "";
		double size = 0;
		double sumCount = 0;
		 @Override
		protected String doInBackground(String... address) {
					try {
								filename= URLUtil.guessFileName(address[0], null, null);
				urit = Uri.parse(save.getString("DIRECT_FOLDER_URI", ""));
				path = DocumentFile.fromTreeUri(AutoinjectActivity.this, urit);
				path1 = path.createFile("*/*", filename.toLowerCase());
				int resCode = -1;
										java.io.InputStream in = null;
										java.net.URL url = new java.net.URL(address[0]);
										java.net.URLConnection urlConn = url.openConnection();
										if (!(urlConn instanceof java.net.HttpURLConnection)) {
													throw new java.io.IOException("URL is not an Http URL"); }
										java.net.HttpURLConnection httpConn = (java.net.HttpURLConnection) urlConn; httpConn.setAllowUserInteraction(false); httpConn.setInstanceFollowRedirects(true); httpConn.setRequestMethod("GET"); httpConn.connect();
										resCode = httpConn.getResponseCode();
										if (resCode == java.net.HttpURLConnection.HTTP_OK) {
													in = httpConn.getInputStream();
													size = httpConn.getContentLength();
													
										} else { result = "There was an error"; }
				OutputStream output = getContentResolver().openOutputStream(path1.getUri());
						
						try {
									int bytesRead;
									sumCount = 0;
									byte[] buffer = new byte[1024];
									while ((bytesRead = in.read(buffer)) != -1) {
												output.write(buffer, 0, bytesRead);
												sumCount += bytesRead;
												if (size > 0) {
															publishProgress((int)Math.round(sumCount*100 / size));
												}
									}
						} finally {
									output.close();
						}
						result ="";
						in.close();
			} catch (java.net.MalformedURLException e) {
						result = e.getMessage();
			} catch (java.io.IOException e) {
						result = e.getMessage();
			} catch (Exception e) {
						result = e.toString();
			}
				return result;
				
		}
		@Override
		protected void onProgressUpdate(Integer... values) {
				super.onProgressUpdate(values);
			hud.setProgress(values[values.length - 1]);
			hud.setDetailsLabel(String.valueOf((long)(values[values.length - 1])).concat("%"));
		}
		protected void onPostExecute(String s){
				file = filename;
			suri = Uri.parse(save.getString("DIRECT_FOLDER_URI", ""));
			urit = Uri.parse(save.getString("DIRECT_FOLDER_URI", "").concat(filename.toLowerCase())); 
			filepath = DocumentFile.fromTreeUri(AutoinjectActivity.this, urit);
				Decompress d = new Decompress(filepath, path, AutoinjectActivity.this); 
				d.execute();
		}
	}
	private class Decompress extends AsyncTask<Void, Integer, Integer> { 
		DocumentFile srcZipFile;
		DocumentFile destDir;
		Context ctx;
		int result = 0;
		final AlertDialog.Builder dialog = new AlertDialog.Builder(AutoinjectActivity.this);
		final AlertDialog unzipDialog = dialog.create();
		final View inflate = getLayoutInflater().inflate(R.layout.unzip, null);
		LinearLayout l2 = inflate.findViewById(R.id.linear2);
		LinearLayout l3 = inflate.findViewById(R.id.linear3);
		TextView t2 = inflate.findViewById(R.id.textview2);
		public Decompress(DocumentFile srcZipFile, DocumentFile destDir, Context ctx) {
			super();		
			this.srcZipFile = srcZipFile; 		
			this.destDir = destDir;		
			this.ctx = ctx;
		}
		
		@Override	protected void onPreExecute() {
			{
					android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
					int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
					SketchUi.setColor(0xFFE0E0E0);SketchUi.setCornerRadii(new float[]{
							d*10,d*10,d*0 ,d*0,d*0,d*0 ,d*10,d*10});
					l2.setBackground(SketchUi);
			}
			{
					android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
					int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
					SketchUi.setColor(0xFF121F2B);SketchUi.setCornerRadii(new float[]{
							d*0,d*0,d*10 ,d*10,d*10,d*10 ,d*0,d*0});
					l3.setBackground(SketchUi);
			}
			unzipDialog.setView(inflate);
			unzipDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
			unzipDialog.setCancelable(false);
			unzipDialog.show();
		}
		 @Override
		protected Integer doInBackground(Void... params){		
				int count = 0;
				
				
				try {
						ZipEntry entry; 
						InputStream inputStream = getContentResolver().openInputStream(srcZipFile.getUri()); 
						
						BufferedInputStream bis = new BufferedInputStream(inputStream);
						
						java.util.zip.ZipInputStream zipInputStream = new java.util.zip.ZipInputStream(bis);
						
						int numFiles = 0;
						
						 
						
						
						while ((entry = zipInputStream.getNextEntry()) != null) { 
								DocumentFile currentDestDir = destDir; 
								DocumentFile parentDir = destDir; 
								DocumentFile childDir = null;
								count++;
								publishProgress((int)count);
								
								if (entry.toString().endsWith("/")) { 
										
										String[] tempStr = entry.toString().split("/"); 
										
										
										 for (String st : tempStr) { 
												
												if (st == "UI"){
														childDir = parentDir.findFile(st.toUpperCase());
														
														if (childDir == null) { 
																childDir = parentDir.createDirectory(st);
														}
														
												}else{
														childDir = parentDir.findFile(st);
														
														if (childDir == null) { 
																childDir = parentDir.createDirectory(st);
														}
														
												}
												 
												parentDir = childDir; 
										} 
										// returns null 
								}
								
								else if (entry.toString().contains("/")) { 
										
										String[] tempStr = entry.toString().split("/"); 
										
										for (int i = 0; i < tempStr.length - 1; i++) { 
												
												childDir = parentDir.findFile(tempStr[i]); 
												
												if (childDir == null){ 
														childDir = parentDir.createDirectory(tempStr[i]); } 
												parentDir = childDir; 
										} 
										String finalFileName = entry.toString().substring(entry.toString().lastIndexOf("/") + 1); 
										
										unzipFile(entry, zipInputStream, parentDir);
										
										
										 } // Like ---> / 
								else if (entry.toString().equals("/")) 
								{
										 
										 } else { 
										unzipFile(entry, zipInputStream, destDir);
										
										
								}
						}
						inputStream.close(); 
						 }catch(IOException e1){
						//toast
						SketchwareUtil.showMessage(getApplicationContext(), e1.toString());
						
						 } 
				
				return result;
				
		} 
		private void unzipFile(ZipEntry fileEntry, java.util.zip.ZipInputStream zipInputStream, DocumentFile finalDir) throws IOException {
				 int readLen; 
				
				if (!fileEntry.isDirectory()) {
						DocumentFile tempFile = null;
						DocumentFile df = null;
														
														
														//Now you have to tell it what file extensions ("MIME" type) you want to use, e.g.:
						
						
						tempFile = DocumentFile.fromSingleUri(AutoinjectActivity.this, Uri.parse(finalDir.getUri().toString().concat(Uri.encode("/").concat(Uri.parse(fileEntry.toString()).getLastPathSegment()))));
						
						
						if (tempFile.exists()) {
								
								df = tempFile;
									
						}else {
								
								df = finalDir.createFile("*/*",  Uri.parse(fileEntry.toString()).getLastPathSegment());
						}
							
						try {
								
								OutputStream out = getContentResolver().openOutputStream(df.getUri());
																BufferedOutputStream bos = new BufferedOutputStream(out);
								long zipfilesize = fileEntry.getSize();
								
								byte[] buffer = new byte[4096];
																int len = 0;
																int totlen = 0;
								
								int count = -1;
								while ((count = zipInputStream.read(buffer)) != -1)
								{
										out.write(buffer, 0, count);
								}
								out.close(); 
								bos.close();
								
								 }catch(Exception e2){
								
								final String e22 = e2.toString();
								runOnUiThread(new Runnable() { 
										public void run() { 
												SketchwareUtil.showMessage(getApplicationContext(), e22);
										}});
								
						}
						
				}
		}
		
		protected void onProgressUpdate(Integer... progress) {
			t2.setText(String.valueOf(progress[progress.length - 1]).concat(" Files Extracted.."));
		}
		@Override
		protected void onPostExecute(Integer result) {
				filepath = DocumentFile.fromTreeUri(AutoinjectActivity.this, urit);
			try{
					        DocumentsContract.deleteDocument(getApplicationContext().getContentResolver(), urit);
				urit = Uri.parse(save.getString("DIRECT_FOLDER_URI", "").concat(file.toLowerCase())); 
				unzipDialog.dismiss();
				LayoutInflater CustomToastLT = getLayoutInflater(); 
				View CustomToastVT = CustomToastLT.inflate(R.layout.success, null);
				Toast CustomToastT = Toast.makeText(getApplicationContext(),"",500);
				CustomToastT.setView(CustomToastVT);
				CustomToastT.show();
			} catch (FileNotFoundException e) {
				unzipDialog.dismiss();
				SketchwareUtil.showMessage(getApplicationContext(), "Failed to Inject");
			}
		}
	}
	
	
	public void _MoreBlock() {
	}
	
	Boolean Ikuza (DocumentFile srcZipFile, DocumentFile destDir) {
		
		try {
			
			ZipEntry entry; 
			InputStream inputStream = getContentResolver().openInputStream(srcZipFile.getUri()); 
			
			BufferedInputStream bis = new BufferedInputStream(inputStream);
			
			java.util.zip.ZipInputStream zipInputStream = new java.util.zip.ZipInputStream(bis);
			
			
			 
			while ((entry = zipInputStream.getNextEntry()) != null) { 
				DocumentFile currentDestDir = destDir; 
				DocumentFile parentDir = destDir; 
				DocumentFile childDir = null;
				
				if (entry.toString().endsWith("/")) { 
					
					String[] tempStr = entry.toString().split("/"); 
					
					
					 for (String st : tempStr) { 
						
						String meta = Arrays.toString(tempStr);
						if(meta == "Ui"){
							childDir = parentDir.findFile(meta.toUpperCase());
							if (childDir == null) { 
								
								childDir = parentDir.createDirectory(st);
								//swtchend
							} 
						}else{
							childDir = parentDir.findFile(st);
							if (childDir == null) { 
								
								childDir = parentDir.createDirectory(st);
								//swtchend
							} 
						}
						
						 
						parentDir = childDir; 
					} 
					// returns null 
				}
				
				else if (entry.toString().contains("/")) { 
					
					String[] tempStr = entry.toString().split("/"); 
					
					for (int i = 0; i < tempStr.length - 1; i++) { 
						
						childDir = parentDir.findFile(tempStr[i]); 
						
						if (childDir == null){ 
							childDir = parentDir.createDirectory(tempStr[i]); } 
						parentDir = childDir; 
					} 
					String finalFileName = entry.toString().substring(entry.toString().lastIndexOf("/") + 1); 
					
					unzipFile(entry, zipInputStream, parentDir);
					
					
					 } // Like ---> / 
				else if (entry.toString().equals("/")) 
				{
					 
					 } else { 
					unzipFile(entry, zipInputStream, destDir);
					
					
				}
			}
			inputStream.close(); 
			 }catch(IOException e1){
			//toast
			SketchwareUtil.showMessage(getApplicationContext(), e1.toString());
			return false;
			 } 
		return true;
		
	} 
	private void unzipFile(ZipEntry fileEntry, java.util.zip.ZipInputStream zipInputStream, DocumentFile finalDir) throws IOException {
		 int readLen; 
		
		if (!fileEntry.isDirectory()) {
			DocumentFile tempFile = null;
			DocumentFile df = null;
											
											
											//Now you have to tell it what file extensions ("MIME" type) you want to use, e.g.:
			
			
			tempFile = DocumentFile.fromSingleUri(this, Uri.parse(finalDir.getUri().toString().concat(Uri.encode("/").concat(Uri.parse(fileEntry.toString()).getLastPathSegment()))));
			
			
			if (tempFile.exists()) {
				
				df = tempFile;
					
			}else {
				
				df = finalDir.createFile("*/*",  Uri.parse(fileEntry.toString()).getLastPathSegment());
			}
				
			try {
				
				OutputStream out = getContentResolver().openOutputStream(df.getUri());
												BufferedOutputStream bos = new BufferedOutputStream(out);
				long zipfilesize = fileEntry.getSize();
				
				byte[] buffer = new byte[4096];
												int len = 0;
												int totlen = 0;
				
				int count = -1;
				while ((count = zipInputStream.read(buffer)) != -1)
				{
					out.write(buffer, 0, count);
				}
				out.close(); 
				bos.close();
				
				 }catch(Exception e2){
				//toast
				SketchwareUtil.showMessage(getApplicationContext(), e2.toString());
				
			}
			
		}
		 }
	
	{
	}
	boolean hasManageExternalStoragePermission() 
	{
		 if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) { 
			if (Environment.isExternalStorageManager()) {
				 return true;
				 } else {
				 if (Environment.isExternalStorageLegacy()) { return true; 
				} 
				try { 
					Intent intent = new Intent(); intent.setAction(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION); intent.setData(Uri.parse("package:".concat(getApplicationContext().getPackageName().toString())
					)); 
					startActivityForResult(intent, 1);
					  
					return false; 
				} catch (Exception e) { 
					return false; 
				}
				 }
			 } 
		{
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) { 
				if (Environment.isExternalStorageLegacy()) { 
					return true;
					 } else {
					 try { 
						Intent intent = new Intent(); intent.setAction(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION); intent.setData(Uri.parse("package:".concat(getApplicationContext().getPackageName().toString())
						)); 
						startActivityForResult(intent, 1); 
						
						return false;
						 } catch (Exception e) { 
						return true; 
					} 
				} 
			}
			 return true; 
		}
	}
	Boolean CyberUnzip(String destDir,String fileZip){
		try
		{
			java.io.File outdir = new java.io.File(destDir);
			java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(new java.io.FileInputStream(fileZip));
			java.util.zip.ZipEntry entry;
			String name, dir;
			while ((entry = zin.getNextEntry()) != null)
			{
				name = entry.getName();
				if(entry.isDirectory())
				{
					mkdirs(outdir, name);
					continue;
				}
				
				/* this part is necessary because file entry can come before
* directory entry where is file located
* i.e.:
* /foo/foo.txt
* /foo/
*/
				
				dir = dirpart(name);
				if(dir != null)
				mkdirs(outdir, dir);
				
				extractFile(zin, outdir, name);
			}
			zin.close();
		}
		catch (java.io.IOException e)
		{
			return false;
		}
		return true;
		
	}
	private static void extractFile(java.util.zip.ZipInputStream in, java.io.File outdir, String name) throws java.io.IOException
	{
		byte[] buffer = new byte[4096];
		java.io.BufferedOutputStream out = new java.io.BufferedOutputStream(new java.io.FileOutputStream(new java.io.File(outdir, name)));
		int count = -1;
		while ((count = in.read(buffer)) != -1)
		out.write(buffer, 0, count);
		out.close();
	}
	
	private static void mkdirs(java.io.File outdir, String path)
	{
		java.io.File d = new java.io.File(outdir, path);
		if(!d.exists())
		d.mkdirs();
	}
	
	private static String dirpart(String name)
	{
		int s = name.lastIndexOf(java.io.File.separatorChar);
		return s == -1 ? null : name.substring(0, s);
	}
	{
	}
	
	
	public void _Backup() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
				try {
				muri = Uri.parse(save.getString("DIRECT_FOLDER_URI", ""));
				    mfile = DocumentFile.fromTreeUri(this, muri);
				                    
				if (!mfile.canRead() || !mfile.canWrite()) {
					_PermissionDialog();
				}
				else {
					if (getIntent().hasExtra("backup")) {
						new Auto11().execute(getIntent().getStringExtra("backup").replace("blob", "raw"));
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "No link Available");
					}
				}
			} catch (Exception e) {
				_PermissionDialog();
			}	 
			}else{
					 if (Build.VERSION.SDK_INT >= 23) {
							if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_DENIED) {
									requestPermissions(new String[] {android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
							}
							else {
					if (getIntent().hasExtra("backup")) {
						DownloaderDialogFragmentActivity z = new DownloaderDialogFragmentActivity();
						z.show( getSupportFragmentManager(),"");
						save.edit().putString("link", getIntent().getStringExtra("backup").replace("blob", "raw")).commit();
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "No link Available");
					}
							}
					}
					else {
				if (getIntent().hasExtra("backup")) {
					DownloaderDialogFragmentActivity z = new DownloaderDialogFragmentActivity();
					z.show( getSupportFragmentManager(),"");
					save.edit().putString("link", getIntent().getStringExtra("backup").replace("blob", "raw")).commit();
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "No link Available");
				}
					}
			}
	}
	
	
	public void _PermissionDialog() {
		CustomDialog = new AlertDialog.Builder(AutoinjectActivity.this).create();
		LayoutInflater CustomDialogLI = getLayoutInflater();
		View CustomDialogCV = (View) CustomDialogLI.inflate(R.layout.permission, null);
		CustomDialog.setView(CustomDialogCV);
		CustomDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		final TextView t1 = (TextView)
		CustomDialogCV.findViewById(R.id.textview1);
		final LinearLayout l5 = (LinearLayout)
		CustomDialogCV.findViewById(R.id.linear5);
		t1.setText("A N D R O I D  ".concat(release));
		l5.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View _view){
				_AskPermission(linear1);
			}
		});
		CustomDialog.setCancelable(true);
		CustomDialog.show();
	}
	
	
	public void _AskPermission(final View _view) {
		intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
		intent.setAction(Intent.ACTION_OPEN_DOCUMENT_TREE);
		muri = Uri.parse("content://com.android.externalstorage.documents/tree/primary%3AAndroid/document/primary%3AAndroid%2Fdata%2Fcom.mobile.legends%2Ffiles%2Fdragon2017");
		    intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, muri);
		        startActivityForResult(intent, NEW_FOLDER_REQUEST_CODE);
	}
	
	
	public void _InjectSkin(final double _position, final ArrayList<HashMap<String, Object>> _data) {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
				try {
				muri = Uri.parse(save.getString("DIRECT_FOLDER_URI", ""));
				    mfile = DocumentFile.fromTreeUri(this, muri);
				                    
				if (!mfile.canRead() || !mfile.canWrite()) {
					_PermissionDialog();
				}
				else {
					if (_data.get((int)_position).containsKey("inject")) {
						new Auto11().execute(_data.get((int)_position).get("inject").toString().replace("blob", "raw"));
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "No link Available");
					}
				}
			} catch (Exception e) {
				_PermissionDialog();
			}	 
			}else{
					 if (Build.VERSION.SDK_INT >= 23) {
							if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_DENIED) {
									requestPermissions(new String[] {android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
							}
							else {
					if (_data.get((int)_position).containsKey("inject")) {
						DownloaderDialogFragmentActivity z = new DownloaderDialogFragmentActivity();
						z.show( getSupportFragmentManager(),"");
						save.edit().putString("link", _data.get((int)_position).get("inject").toString().replace("blob", "raw")).commit();
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "No link Available");
					}
							}
					}
					else {
				if (_data.get((int)_position).containsKey("inject")) {
					DownloaderDialogFragmentActivity z = new DownloaderDialogFragmentActivity();
					z.show( getSupportFragmentManager(),"");
					save.edit().putString("link", _data.get((int)_position).get("inject").toString().replace("blob", "raw")).commit();
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "No link Available");
				}
					}
			}
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.skin, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout container = _view.findViewById(R.id.container);
			final androidx.cardview.widget.CardView card = _view.findViewById(R.id.card);
			final ImageView image = _view.findViewById(R.id.image);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final LinearLayout linear7 = _view.findViewById(R.id.linear7);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				SketchUi.setColor(0xFF0B141A);
				SketchUi.setCornerRadius(d*10);
				linear1.setElevation(d*5);
				linear1.setBackground(SketchUi);
			}
			{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				SketchUi.setColor(0xFF101010);
				SketchUi.setCornerRadius(d*5);
				linear7.setElevation(d*5);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF9E9E9E}), SketchUi, null);
				linear7.setBackground(SketchUiRD);
				linear7.setClickable(true);
			}
			((ViewGroup) image.getParent()).removeView(image);
			((ViewGroup) container.getParent()).removeView(container);
			android.widget.RelativeLayout rl = new android.widget.RelativeLayout(AutoinjectActivity.this);
			
			rl.setLayoutParams(new LinearLayout.LayoutParams(-1,-1));
			
			card.removeAllViews();
			
			card.addView(rl);
			
			rl.addView(image);
			
			rl.addView(container);
			Animation animation; animation = AnimationUtils.loadAnimation( getApplicationContext(), android.R.anim.fade_in ); animation.setDuration(700); image.startAnimation(animation); animation = null;
			android.graphics.drawable.GradientDrawable linear5gd = new android.graphics.drawable.GradientDrawable();
			
			linear5gd.setColor(0xFF22485E);
			
			linear5gd.setStroke((int)0, Color.TRANSPARENT);
			
			linear5gd.setCornerRadii(new float[]{(int)30,(int)30,(int)0,(int)0,(int)0,(int)0,(int)30,(int)30});
			
			linear5.setBackground(linear5gd);
			
			linear5.setElevation(0);
			android.graphics.drawable.GradientDrawable linear6gd = new android.graphics.drawable.GradientDrawable();
			
			linear6gd.setColor(Color.TRANSPARENT);
			
			linear6gd.setStroke((int)0, Color.TRANSPARENT);
			
			linear6gd.setCornerRadii(new float[]{(int)25,(int)25,(int)0,(int)0,(int)0,(int)0,(int)25,(int)25});
			
			linear6.setBackground(linear6gd);
			
			linear6.setElevation(0);
			card.setCardBackgroundColor(Color.TRANSPARENT);
			card.setRadius((float)15);
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("img1").toString())).into(image);
			if (_data.get((int)_position).containsKey("txt1")) {
				textview2.setText(_data.get((int)_position).get("txt1").toString());
			}
			else {
				textview2.setText("");
			}
			_Adapter(imageview1, _position, _data);
			linear7.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View _view){
					if (SketchwareUtil.isConnected(getApplicationContext())) {
						_InjectSkin(_position, _data);
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "Please check your internet connection");
					}
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}