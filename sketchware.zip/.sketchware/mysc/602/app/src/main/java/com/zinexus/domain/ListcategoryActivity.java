package com.zinexus.domain;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.azoft.carousellayoutmanager.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.bumptech.glide.Glide;
import com.downloader.*;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.kaopiz.kprogresshud.*;
import com.twotoasters.jazzylistview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import jp.wasabeef.picasso.transformations.*;
import me.everything.*;
import org.json.*;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;

public class ListcategoryActivity extends AppCompatActivity {
	
	private String api = "";
	private double length = 0;
	private double number = 0;
	private String value = "";
	private String position = "";
	
	private ArrayList<HashMap<String, Object>> listmap_listview1 = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear9;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private TextView textview1;
	private LinearLayout linear8;
	private TextView textview2;
	private LinearLayout linear10;
	private LinearLayout linear13;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private EditText edittext1;
	private JazzyListView listview1;
	
	private RequestNetwork internet;
	private RequestNetwork.RequestListener _internet_request_listener;
	private Intent intent = new Intent();
	private SharedPreferences save;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.listcategory);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear9 = findViewById(R.id.linear9);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		textview1 = findViewById(R.id.textview1);
		linear8 = findViewById(R.id.linear8);
		textview2 = findViewById(R.id.textview2);
		linear10 = findViewById(R.id.linear10);
		linear13 = findViewById(R.id.linear13);
		linear11 = findViewById(R.id.linear11);
		linear12 = findViewById(R.id.linear12);
		edittext1 = findViewById(R.id.edittext1);
		listview1 = findViewById(R.id.listview1);
		internet = new RequestNetwork(this);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				try {
					listmap_listview1 = new Gson().fromJson(api, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					length = listmap_listview1.size();
					number = length - 1;
					for(int _repeat17 = 0; _repeat17 < (int)(length); _repeat17++) {
						value = listmap_listview1.get((int)number).get("name").toString();
						if (!(_charSeq.length() > value.length()) && value.toLowerCase().contains(_charSeq.toLowerCase())) {
							
						}
						else {
							listmap_listview1.remove((int)(number));
							listview1.setAdapter(new Listview1Adapter(listmap_listview1));
						}
						number--;
					}
					listview1.setAdapter(new Listview1Adapter(listmap_listview1));
				} catch (Exception e) {
					 
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		_internet_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try {
					save.edit().putString("category_response", _response).commit();
					listmap_listview1 = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					listview1.setAdapter(new Listview1Adapter(listmap_listview1));
					((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					api = new Gson().toJson(listmap_listview1);
				} catch (Exception e) {
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				try {
					listmap_listview1 = new Gson().fromJson(save.getString("category_response", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					listview1.setAdapter(new Listview1Adapter(listmap_listview1));
					((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					api = new Gson().toJson(listmap_listview1);
				} catch (Exception e) {
					 
				}
			}
		};
	}
	
	private void initializeLogic() {
		_SetStatusBarColor("#0B141D", "#0B141D");
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF121F2B);
			SketchUi.setCornerRadius(d*12);
			linear3.setElevation(d*5);
			linear3.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF121F2B);SketchUi.setCornerRadii(new float[]{
				d*0,d*0,d*0 ,d*0,d*25,d*25 ,d*25,d*25});
			linear12.setElevation(d*5);
			linear12.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF121F2B);SketchUi.setCornerRadii(new float[]{
				d*15,d*15,d*15 ,d*15,d*0,d*0 ,d*0,d*0});
			linear13.setElevation(d*5);
			linear13.setBackground(SketchUi);
		}
		listview1.setHorizontalScrollBarEnabled(false);
		listview1.setVerticalScrollBarEnabled(false);
		listview1.setOverScrollMode(ListView.OVER_SCROLL_NEVER);
		OverScrollDecoratorHelper.setUpOverScroll(listview1);
		if (getIntent().hasExtra("category")) {
			textview1.setText(getIntent().getStringExtra("category"));
		}
		if (getIntent().hasExtra("count")) {
			textview2.setText(getIntent().getStringExtra("count"));
		}
		listview1.setTransitionEffect(new com.twotoasters.jazzylistview.effects.SlideInEffect());
		edittext1.setFilters(new InputFilter[]{new InputFilter.LengthFilter((int) 40)});
		edittext1.setCursorVisible(false);
		_Api();
	}
	
	
	@Override
	public void onBackPressed() {
		startActivity(new Intent(ListcategoryActivity.this, HomeActivity.class)); Animatoo.animateFade(ListcategoryActivity.this);
	}
	public void _SetStatusBarColor(final String _color1, final String _color2) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) { 
			   Window w = this.getWindow(); w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS); w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			   w.setStatusBarColor(Color.parseColor(_color1)); w.setNavigationBarColor(Color.parseColor(_color2));
		}
	}
	
	
	public void _Api() {
		if (getIntent().getStringExtra("category").equals("Assassin")) {
			internet.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/New-Assassin-Data/", "a", _internet_request_listener);
		}
		else {
			if (getIntent().getStringExtra("category").equals("Tank")) {
				internet.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/New-Tank-Data/", "a", _internet_request_listener);
			}
			else {
				if (getIntent().getStringExtra("category").equals("Fighter")) {
					internet.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/New-Fighter-Data/", "a", _internet_request_listener);
				}
				else {
					if (getIntent().getStringExtra("category").equals("Marksman")) {
						internet.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/New-Marksman-Data/", "a", _internet_request_listener);
					}
					else {
						if (getIntent().getStringExtra("category").equals("Mage")) {
							internet.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/New-Mage-Data/", "a", _internet_request_listener);
						}
						else {
							if (getIntent().getStringExtra("category").equals("Support")) {
								internet.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/New-Support-Data/", "a", _internet_request_listener);
							}
						}
					}
				}
			}
		}
	}
	
	
	public void _GradientDrawable(final View _view, final double _radius, final double _stroke, final double _shadow, final String _color, final String _borderColor, final boolean _ripple, final boolean _clickAnim, final double _animDuration) {
		if (_ripple) {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
			android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor("#9E9E9E")});
			android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , gd, null);
			_view.setClickable(true);
			_view.setBackground(ripdrb);
		}
		else {
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
			gd.setColor(Color.parseColor(_color));
			gd.setCornerRadius((int)_radius);
			gd.setStroke((int)_stroke,Color.parseColor(_borderColor));
			_view.setBackground(gd);
			if (Build.VERSION.SDK_INT >= 21){
				_view.setElevation((int)_shadow);}
		}
		if (_clickAnim) {
			_view.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()){
						case MotionEvent.ACTION_DOWN:{
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues(0.9f);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues(0.9f);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							break;
						}
						case MotionEvent.ACTION_UP:{
							
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues((float)1);
							scaleX.setDuration((int)_animDuration);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues((float)1);
							scaleY.setDuration((int)_animDuration);
							scaleY.start();
							
							break;
						}
					}
					return false;
				}
			});
		}
	}
	
	
	public void _listViewAdapter(final double _position, final ArrayList<HashMap<String, Object>> _data) {
		intent.putExtra("Category", getIntent().getStringExtra("category"));
		intent.putExtra("List", getIntent().getStringExtra("list"));
		intent.putExtra("name", _data.get((int)_position).get("name").toString());
		intent.putExtra("url", _data.get((int)_position).get("url").toString());
		intent.putExtra("number", _data.get((int)_position).get("number").toString());
		if (_data.get((int)_position).containsKey("backup")) {
			intent.putExtra("backup", _data.get((int)_position).get("backup").toString());
		}
		if (_data.get((int)_position).containsKey("landscape")) {
			intent.putExtra("landscape", _data.get((int)_position).get("landscape").toString());
		}
		if (_data.get((int)_position).containsKey("name1")) {
				intent.putExtra("name1", _data.get((int)_position).get("name1").toString());
		}
		if (_data.get((int)_position).containsKey("name2")) {
				intent.putExtra("name2", _data.get((int)_position).get("name2").toString());
		}
		if (_data.get((int)_position).containsKey("name3")) {
				intent.putExtra("name3", _data.get((int)_position).get("name3").toString());
		}
		if (_data.get((int)_position).containsKey("name4")) {
				intent.putExtra("name4", _data.get((int)_position).get("name4").toString());
		}
		if (_data.get((int)_position).containsKey("name5")) {
				intent.putExtra("name5", _data.get((int)_position).get("name5").toString());
		}
		if (_data.get((int)_position).containsKey("name6")) {
				intent.putExtra("name6", _data.get((int)_position).get("name6").toString());
		}
		if (_data.get((int)_position).containsKey("name7")) {
				intent.putExtra("name7", _data.get((int)_position).get("name7").toString());
		}
		if (_data.get((int)_position).containsKey("name8")) {
				intent.putExtra("name8", _data.get((int)_position).get("name8").toString());
		}
		if (_data.get((int)_position).containsKey("name9")) {
				intent.putExtra("name9", _data.get((int)_position).get("name9").toString());
		}
		if (_data.get((int)_position).containsKey("name10")) {
				intent.putExtra("name10", _data.get((int)_position).get("name10").toString());
		}
		if (_data.get((int)_position).containsKey("skin1")) {
				intent.putExtra("skin1", _data.get((int)_position).get("skin1").toString());
		}
		if (_data.get((int)_position).containsKey("skin2")) {
				intent.putExtra("skin2", _data.get((int)_position).get("skin2").toString());
		}
		if (_data.get((int)_position).containsKey("skin3")) {
				intent.putExtra("skin3", _data.get((int)_position).get("skin3").toString());
		}
		if (_data.get((int)_position).containsKey("skin4")) {
				intent.putExtra("skin4", _data.get((int)_position).get("skin4").toString());
		}
		if (_data.get((int)_position).containsKey("skin5")) {
				intent.putExtra("skin5", _data.get((int)_position).get("skin5").toString());
		}
		if (_data.get((int)_position).containsKey("skin6")) {
				intent.putExtra("skin6", _data.get((int)_position).get("skin6").toString());
		}
		if (_data.get((int)_position).containsKey("skin7")) {
				intent.putExtra("skin7", _data.get((int)_position).get("skin7").toString());
		}
		if (_data.get((int)_position).containsKey("skin8")) {
				intent.putExtra("skin8", _data.get((int)_position).get("skin8").toString());
		}
		if (_data.get((int)_position).containsKey("skin9")) {
				intent.putExtra("skin9", _data.get((int)_position).get("skin9").toString());
		}
		if (_data.get((int)_position).containsKey("script1")) {
				intent.putExtra("script1", _data.get((int)_position).get("script1").toString());
		}
		if (_data.get((int)_position).containsKey("script2")) {
				intent.putExtra("script2", _data.get((int)_position).get("script2").toString());
		}
		if (_data.get((int)_position).containsKey("script3")) {
				intent.putExtra("script3", _data.get((int)_position).get("script3").toString());
		}
		if (_data.get((int)_position).containsKey("script4")) {
				intent.putExtra("script4", _data.get((int)_position).get("script4").toString());
		}
		if (_data.get((int)_position).containsKey("script5")) {
				intent.putExtra("script5", _data.get((int)_position).get("script5").toString());
		}
		if (_data.get((int)_position).containsKey("script6")) {
				intent.putExtra("script6", _data.get((int)_position).get("script6").toString());
		}
		if (_data.get((int)_position).containsKey("script7")) {
				intent.putExtra("script7", _data.get((int)_position).get("script7").toString());
		}
		if (_data.get((int)_position).containsKey("script8")) {
				intent.putExtra("script8", _data.get((int)_position).get("script8").toString());
		}
		if (_data.get((int)_position).containsKey("script9")) {
				intent.putExtra("script9", _data.get((int)_position).get("script9").toString());
		}
		if (_data.get((int)_position).containsKey("logo1")) {
				intent.putExtra("logo1", _data.get((int)_position).get("logo1").toString());
		}
		if (_data.get((int)_position).containsKey("logo2")) {
				intent.putExtra("logo2", _data.get((int)_position).get("logo2").toString());
		}
		if (_data.get((int)_position).containsKey("logo3")) {
				intent.putExtra("logo3", _data.get((int)_position).get("logo3").toString());
		}
		if (_data.get((int)_position).containsKey("logo4")) {
				intent.putExtra("logo4", _data.get((int)_position).get("logo4").toString());
		}
		if (_data.get((int)_position).containsKey("logo5")) {
				intent.putExtra("logo5", _data.get((int)_position).get("logo5").toString());
		}
		if (_data.get((int)_position).containsKey("logo6")) {
				intent.putExtra("logo6", _data.get((int)_position).get("logo6").toString());
		}
		if (_data.get((int)_position).containsKey("logo7")) {
				intent.putExtra("logo7", _data.get((int)_position).get("logo7").toString());
		}
		if (_data.get((int)_position).containsKey("logo8")) {
				intent.putExtra("logo8", _data.get((int)_position).get("logo8").toString());
		}
		if (_data.get((int)_position).containsKey("logo9")) {
				intent.putExtra("logo9", _data.get((int)_position).get("logo9").toString());
		}
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.list, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = _view.findViewById(R.id.circleimageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			
			_GradientDrawable(linear1, 0, 0, 0, "#121F2B", "#000000", true, false, 0);
			circleimageview1.setCircleBackgroundColor(Color.TRANSPARENT);
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("url").toString())).into(circleimageview1);
			textview1.setText(_data.get((int)_position).get("name").toString());
			if (_data.get((int)_position).containsKey("click")) {
				if (_data.get((int)_position).get("click").toString().equals("false")) {
					textview2.setText("Not working");
					textview2.setTextColor(0xFFF44336);
				}
			}
			else {
				if (_data.get((int)_position).containsKey("number")) {
					textview2.setText(_data.get((int)_position).get("number").toString().concat(" Available Skin's"));
					textview2.setTextColor(0xFF757575);
				}
				else {
					textview2.setText("");
					textview2.setTextColor(0xFF757575);
				}
			}
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (_data.get((int)_position).containsKey("click")) {
						if (_data.get((int)_position).get("click").toString().equals("false")) {
							SketchwareUtil.showMessage(getApplicationContext(), "Not available for now");
						}
					}
					else {
						intent.setClass(getApplicationContext(), AutoinjectActivity.class);
						_listViewAdapter(_position, _data);
						startActivity(intent);
						overridePendingTransition(R.anim.fin, R.anim.fout);
					}
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}