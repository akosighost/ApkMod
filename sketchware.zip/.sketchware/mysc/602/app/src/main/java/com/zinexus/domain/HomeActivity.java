package com.zinexus.domain;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.azoft.carousellayoutmanager.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.bumptech.glide.Glide;
import com.downloader.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.kaopiz.kprogresshud.*;
import com.twotoasters.jazzylistview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import jp.wasabeef.picasso.transformations.*;
import me.everything.*;
import org.json.*;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;

public class HomeActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> map_recyclerview1 = new HashMap<>();
	private String app_version = "";
	private String bsheet2_text = "";
	private HashMap<String, Object> map_send = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> listmap_recyclerview1 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap_recyclerview2 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap_update = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear9;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private TextView textview1;
	private LinearLayout linear8;
	private TextView textview2;
	private ScrollView vscroll1;
	private LinearLayout linear10;
	private LinearLayout linear20;
	private RecyclerView recyclerview1;
	private LinearLayout linear18;
	private LinearLayout linear11;
	private RecyclerView recyclerview2;
	private LinearLayout linear31;
	private LinearLayout linear30;
	private LinearLayout linear34;
	private LinearLayout linear21;
	private TextView textview10;
	private LinearLayout linear19;
	private TextView textview9;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private LinearLayout linear15;
	private ImageView imageview3;
	private TextView textview3;
	private TextView textview4;
	private LinearLayout linear16;
	private ImageView imageview4;
	private TextView textview5;
	private TextView textview6;
	private LinearLayout linear17;
	private ImageView imageview5;
	private TextView textview7;
	private TextView textview8;
	private LinearLayout linear32;
	private LinearLayout linear33;
	private TextView textview13;
	private TextView textview14;
	private CardView cardview1;
	private ImageView imageview6;
	private LinearLayout linear35;
	private TextView textview11;
	private TextView textview12;
	
	private RequestNetwork net1;
	private RequestNetwork.RequestListener _net1_request_listener;
	private RequestNetwork net2;
	private RequestNetwork.RequestListener _net2_request_listener;
	private RequestNetwork net3;
	private RequestNetwork.RequestListener _net3_request_listener;
	private SharedPreferences save;
	private Intent intent = new Intent();
	private  CustomDialog;
	
	private OnCompleteListener Fcm_onCompleteListener;
	private  bsheet1;
	private  bsheet2;
	private DatabaseReference Send = _firebase.getReference("Request/Report");
	private ChildEventListener _Send_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear9 = findViewById(R.id.linear9);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		textview1 = findViewById(R.id.textview1);
		linear8 = findViewById(R.id.linear8);
		textview2 = findViewById(R.id.textview2);
		vscroll1 = findViewById(R.id.vscroll1);
		linear10 = findViewById(R.id.linear10);
		linear20 = findViewById(R.id.linear20);
		recyclerview1 = findViewById(R.id.recyclerview1);
		linear18 = findViewById(R.id.linear18);
		linear11 = findViewById(R.id.linear11);
		recyclerview2 = findViewById(R.id.recyclerview2);
		linear31 = findViewById(R.id.linear31);
		linear30 = findViewById(R.id.linear30);
		linear34 = findViewById(R.id.linear34);
		linear21 = findViewById(R.id.linear21);
		textview10 = findViewById(R.id.textview10);
		linear19 = findViewById(R.id.linear19);
		textview9 = findViewById(R.id.textview9);
		linear12 = findViewById(R.id.linear12);
		linear13 = findViewById(R.id.linear13);
		linear14 = findViewById(R.id.linear14);
		linear15 = findViewById(R.id.linear15);
		imageview3 = findViewById(R.id.imageview3);
		textview3 = findViewById(R.id.textview3);
		textview4 = findViewById(R.id.textview4);
		linear16 = findViewById(R.id.linear16);
		imageview4 = findViewById(R.id.imageview4);
		textview5 = findViewById(R.id.textview5);
		textview6 = findViewById(R.id.textview6);
		linear17 = findViewById(R.id.linear17);
		imageview5 = findViewById(R.id.imageview5);
		textview7 = findViewById(R.id.textview7);
		textview8 = findViewById(R.id.textview8);
		linear32 = findViewById(R.id.linear32);
		linear33 = findViewById(R.id.linear33);
		textview13 = findViewById(R.id.textview13);
		textview14 = findViewById(R.id.textview14);
		cardview1 = findViewById(R.id.cardview1);
		imageview6 = findViewById(R.id.imageview6);
		linear35 = findViewById(R.id.linear35);
		textview11 = findViewById(R.id.textview11);
		textview12 = findViewById(R.id.textview12);
		net1 = new RequestNetwork(this);
		net2 = new RequestNetwork(this);
		net3 = new RequestNetwork(this);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		
		linear35.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final com.google.android.material.bottomsheet.BottomSheetDialog bsheet1D = new com.google.android.material.bottomsheet.BottomSheetDialog(HomeActivity.this);
				View bsheet1V;
				bsheet1V = getLayoutInflater().inflate(R.layout.bsheet1,null );
				bsheet1D.setContentView(bsheet1V);
				bsheet1D.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
				final LinearLayout l1 = (LinearLayout) bsheet1V.findViewById(R.id.linear1);
				final LinearLayout l3 = (LinearLayout) bsheet1V.findViewById(R.id.linear3);
				final LinearLayout l4 = (LinearLayout) bsheet1V.findViewById(R.id.linear4);
				final LinearLayout l5 = (LinearLayout) bsheet1V.findViewById(R.id.linear5);
				final LinearLayout l6 = (LinearLayout) bsheet1V.findViewById(R.id.linear6);
				{
					android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
					int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
					SketchUi.setColor(0xFF121F2B);SketchUi.setCornerRadii(new float[]{
						d*15,d*15,d*15 ,d*15,d*15,d*15 ,d*15,d*15});
					l1.setElevation(d*5);
					l1.setBackground(SketchUi);
				}
				l3.setOnClickListener(new View.OnClickListener(){
					@Override
					public void onClick(View _view){
						bsheet1D.dismiss();
						startActivity(new Intent(HomeActivity.this, SettingsActivity.class)); Animatoo.animateFade(HomeActivity.this);
					}
				});
				l4.setOnClickListener(new View.OnClickListener(){
					@Override
					public void onClick(View _view){
						bsheet1D.dismiss();
						CustomDialog = new AlertDialog.Builder(HomeActivity.this).create();
						LayoutInflater CustomDialogLI = getLayoutInflater();
						View CustomDialogCV = (View) CustomDialogLI.inflate(R.layout.request, null);
						CustomDialog.setView(CustomDialogCV);
						CustomDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
						final LinearLayout l1 = (LinearLayout)
						CustomDialogCV.findViewById(R.id.linear1);
						final LinearLayout l4 = (LinearLayout)
						CustomDialogCV.findViewById(R.id.linear4);
						final LinearLayout l6 = (LinearLayout)
						CustomDialogCV.findViewById(R.id.linear6);
						final LinearLayout l7 = (LinearLayout)
						CustomDialogCV.findViewById(R.id.linear7);
						final TextView t1 = (TextView)
						CustomDialogCV.findViewById(R.id.textview1);
						final EditText edittext1= new EditText(HomeActivity.this);
						
						LinearLayout.LayoutParams l1par = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
						
						edittext1.setLayoutParams(l1par);
						
						l7.addView(edittext1);
						t1.setText("I D - ".concat(Build.HOST));
						edittext1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF121F2B));
						edittext1.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
						edittext1.setAlpha((float)(0.8d));
						edittext1.setTextColor(0xFFBDBDBD);
						edittext1.setTextSize((float) 12);
						edittext1.setFilters(new InputFilter[]{new InputFilter.LengthFilter((int) 100)});
						edittext1.setHint("Fill the blank(s)");
						edittext1.setHintTextColor(0xFF757575);
						edittext1.setCursorVisible(false);
						if (save.contains("recent")) {
							edittext1.setText(save.getString("recent", ""));
						}
						else {
							edittext1.setText("");
						}
						l4.setOnClickListener(new View.OnClickListener(){
							@Override
							public void onClick(View _view){
								if (SketchwareUtil.isConnected(getApplicationContext())) {
									if (edittext1.getText().toString().length() == 0) {
										SketchwareUtil.showMessage(getApplicationContext(), "Fill the blank(s)");
									}
									else {
										try {
											map_send = new HashMap<>();
											map_send.put(Build.HOST, edittext1.getText().toString());
											Send.push().updateChildren(map_send);
											save.edit().putString("recent", edittext1.getText().toString()).commit();
											edittext1.setText("");
											map_send.clear();
											CustomDialog.dismiss();
											SketchwareUtil.showMessage(getApplicationContext(), "Request sent");
										} catch (Exception e) {
											CustomDialog.dismiss();
											SketchwareUtil.showMessage(getApplicationContext(), "Failed to request");
										}
									}
								}
								else {
									SketchwareUtil.showMessage(getApplicationContext(), "Please check your internet connection");
								}
							}
						});
						l6.setOnClickListener(new View.OnClickListener(){
							@Override
							public void onClick(View _view){
								CustomDialog.dismiss();
							}
						});
						CustomDialog.show();
					}
				});
				l5.setOnClickListener(new View.OnClickListener(){
					@Override
					public void onClick(View _view){
						bsheet1D.dismiss();
						final com.google.android.material.bottomsheet.BottomSheetDialog bsheet2D = new com.google.android.material.bottomsheet.BottomSheetDialog(HomeActivity.this);
						View bsheet2V;
						bsheet2V = getLayoutInflater().inflate(R.layout.bsheet2,null );
						bsheet2D.setContentView(bsheet2V);
						bsheet2D.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
						final LinearLayout l1 = (LinearLayout) bsheet2V.findViewById(R.id.linear1);
						final LinearLayout l4 = (LinearLayout) bsheet2V.findViewById(R.id.linear4);
						final ScrollView scroll = (ScrollView) bsheet2V.findViewById(R.id.vscroll1);
						final TextView t2 = (TextView) bsheet2V.findViewById(R.id.textview2);
						final TextView t4 = (TextView) bsheet2V.findViewById(R.id.textview4);
						scroll.setHorizontalScrollBarEnabled(false);
						scroll.setVerticalScrollBarEnabled(false);
						scroll.setOverScrollMode(ScrollView.OVER_SCROLL_NEVER);
						
						t4.setTextSize((int)13);
						
						android.graphics.drawable.GradientDrawable l1gd = new android.graphics.drawable.GradientDrawable();
						
						l1gd.setColor(0xFF121F2B);
						
						l1gd.setStroke((int)0, Color.TRANSPARENT);
						
						l1gd.setCornerRadii(new float[]{(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15});
						
						l1.setBackground(l1gd);
						
						l1.setElevation(5);
						android.graphics.drawable.GradientDrawable l4gd = new android.graphics.drawable.GradientDrawable();
						
						l4gd.setColor(0xFF121F2B);
						
						l4gd.setStroke((int)0, Color.TRANSPARENT);
						
						l4gd.setCornerRadii(new float[]{(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15});
						
						l4.setBackground(l4gd);
						
						l4.setElevation(5);
						t2.setText("Version ".concat(app_version));
						t4.setText(bsheet2_text);
						bsheet2D.show();
					}
				});
				l6.setOnClickListener(new View.OnClickListener(){
					@Override
					public void onClick(View _view){
						SketchwareUtil.showMessage(getApplicationContext(), "Coming soon!");
					}
				});
				bsheet1D.setCancelable(true);
				bsheet1D.show();
			}
		});
		
		_net1_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try {
					listmap_recyclerview2 = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					recyclerview2.setAdapter(new Recyclerview2Adapter(listmap_recyclerview2));
					recyclerview2.setHasFixedSize(true);
					recyclerview2.setLayoutManager(new LinearLayoutManager(HomeActivity.this,LinearLayoutManager.HORIZONTAL, false));
				} catch (Exception e) {
					SketchwareUtil.showMessage(getApplicationContext(), "can't resolve api host");
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
		
		_net2_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try {
					listmap_update = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					try { 
						android.content.pm.PackageManager pm = getApplicationContext().getPackageManager(); android.content.pm.PackageInfo pinfo = pm.getPackageInfo(getApplicationContext().getPackageName().toString(), 0); String your_version = pinfo.versionName;  
						if (!your_version.equals(listmap_update.get((int)0).get("version").toString())) {
							if (listmap_update.get((int)0).containsKey("cancelable")) {
								if (listmap_update.get((int)0).get("cancelable").toString().equals("true")) {
									_Dialog(true);
								}
								else {
									if (listmap_update.get((int)0).get("cancelable").toString().equals("false")) {
										_Dialog(false);
									}
								}
							}
							else {
								
							}
						}
					} catch (android.content.pm.PackageManager.NameNotFoundException e) { e.printStackTrace(); }
				} catch (Exception e) {
					SketchwareUtil.showMessage(getApplicationContext(), "can't resolve api host");
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_net3_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		Fcm_onCompleteListener = new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(Task<InstanceIdResult> task) {
				final boolean _success = task.isSuccessful();
				final String _token = task.getResult().getToken();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				FirebaseInstanceId.getInstance().getInstanceId().addOnCompleteListener(Fcm_onCompleteListener);
			}
		};
		
		_Send_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		Send.addChildEventListener(_Send_child_listener);
	}
	
	private void initializeLogic() {
		_SetStatusBarColor("#0B141D", "#0B141D");
		net1.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/Home-Effect-Data/", "a", _net1_request_listener);
		net2.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/New-Update-App/", "a", _net2_request_listener);
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF121F2B);
			SketchUi.setCornerRadius(d*12);
			linear3.setElevation(d*5);
			linear3.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF121F2B);SketchUi.setCornerRadii(new float[]{
				d*15,d*15,d*0 ,d*0,d*0,d*0 ,d*15,d*15});
			linear12.setElevation(d*5);
			linear12.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF121F2B);
			linear13.setElevation(d*5);
			linear13.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF121F2B);SketchUi.setCornerRadii(new float[]{
				d*0,d*0,d*15 ,d*15,d*15,d*15 ,d*0,d*0});
			linear14.setElevation(d*5);
			linear14.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF121F2B);SketchUi.setCornerRadii(new float[]{
				d*25,d*25,d*25 ,d*25,d*0,d*0 ,d*0,d*0});
			linear19.setElevation(d*5);
			linear19.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF121F2B);SketchUi.setCornerRadii(new float[]{
				d*0,d*0,d*0 ,d*0,d*25,d*25 ,d*25,d*25});
			linear21.setElevation(d*5);
			linear21.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF121F2B);
			SketchUi.setCornerRadius(d*12);
			linear35.setElevation(d*5);
			android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF9E9E9E}), SketchUi, null);
			linear35.setBackground(SketchUiRD);
			linear35.setClickable(true);
		}
		recyclerview2.setHorizontalScrollBarEnabled(false);
		recyclerview2.setVerticalScrollBarEnabled(false);
		recyclerview2.setOverScrollMode(RecyclerView.OVER_SCROLL_NEVER);
		
		vscroll1.setHorizontalScrollBarEnabled(false);
		vscroll1.setVerticalScrollBarEnabled(false);
		vscroll1.setOverScrollMode(ScrollView.OVER_SCROLL_NEVER);
		OverScrollDecoratorHelper.setUpOverScroll(vscroll1);
		android.graphics.drawable.GradientDrawable linear32gd = new android.graphics.drawable.GradientDrawable();
		
		linear32gd.setColor(0xFF22485E);
		
		linear32gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear32gd.setCornerRadii(new float[]{(int)30,(int)30,(int)0,(int)0,(int)0,(int)0,(int)30,(int)30});
		
		linear32.setBackground(linear32gd);
		
		linear32.setElevation(0);
		cardview1.setCardBackgroundColor(Color.TRANSPARENT);
		Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Home-image/raw/main/effects.jpg")).into(imageview6);
		bsheet2_text = "(06/Jun/22)\n\n• Optimized Ui/UX\n• Bug Fixes & Performance improvements\n\n• Added 1 New Heroes\n  Julian [Mage]\n\n• Added New Transformers Skins\n  Roger - Grimlock\n  Aldous - STARSCREAM\n  Popol & Kupa - Soundwave\n\n  Brody - Collector\n  Masha - Seasonal\n  Gord - Seasonal\n\n• Fix Skin\n  Chou - Epic [Fix Effects]\n  Gusion - Kof [Fix Audio & Effects]\n\n• Fix Backup\n  Aldous [29 MB]\n  Alpha [59 MB]\n  Alucard [30 MB]\n  Benedetta [21 MB]\n  Chou [37 MB]\n  Clint [26 MB]\n  Cyclops [28 MB]\n  Fanny [36.9 MB]\n  Franco [29 MB]\n  Freya [27 MB]\n  Granger [39 MB]\n  Lancelot [47 MB]\n  Layla [25 MB]\n  Ling [32 MB]\n  Lunox [32 MB]\n  Moskov [32 MB]\n  Popol & Kupa [16 MB]\n  Pharsa [34 MB]\n  Roger [55 MB]\n  Selena [54 MB]\n  Sun [30 MB]\n  Yi shun - Shin [32 MB]\n  Yu Zhong [29 MB]";
		try { 
			android.content.pm.PackageManager pm = getApplicationContext().getPackageManager(); android.content.pm.PackageInfo pinfo = pm.getPackageInfo(getApplicationContext().getPackageName().toString(), 0); String your_version = pinfo.versionName;  
			app_version = your_version;
			textview2.setText("version : ".concat(app_version));
		} catch (android.content.pm.PackageManager.NameNotFoundException e) { e.printStackTrace(); }
		cardview1.setRadius((float)15);
		cardview1.setCardElevation((float)0);
		_RecyclerView1();
	}
	
	
	@Override
	public void onBackPressed() {
		CustomDialog = new AlertDialog.Builder(HomeActivity.this).create();
		LayoutInflater CustomDialogLI = getLayoutInflater();
		View CustomDialogCV = (View) CustomDialogLI.inflate(R.layout.quit, null);
		CustomDialog.setView(CustomDialogCV);
		CustomDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		final LinearLayout l6 = (LinearLayout)
		CustomDialogCV.findViewById(R.id.linear6);
		final LinearLayout l7 = (LinearLayout)
		CustomDialogCV.findViewById(R.id.linear7);
		l6.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View _view){
				CustomDialog.dismiss();
			}
		});
		l7.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View _view){
				finishAffinity();
			}
		});
		CustomDialog.setCancelable(false);
		CustomDialog.show();
	}
	public void _RecyclerView1() {
		for(int _repeat30 = 0; _repeat30 < (int)(2); _repeat30++) {
			map_recyclerview1 = new HashMap<>();
			map_recyclerview1.put("img1", "https://github.com/akosighost/Home-image/raw/main/Compress_20220305_212231_1439.jpg");
			map_recyclerview1.put("role", "Assassin");
			map_recyclerview1.put("count", "13 Heroes Available");
			listmap_recyclerview1.add(map_recyclerview1);
			map_recyclerview1 = new HashMap<>();
			map_recyclerview1.put("img1", "https://github.com/akosighost/Home-image/raw/main/Compress_20220305_212231_1973.jpg");
			map_recyclerview1.put("role", "Tank");
			map_recyclerview1.put("count", "18 Heroes Available");
			listmap_recyclerview1.add(map_recyclerview1);
			map_recyclerview1 = new HashMap<>();
			map_recyclerview1.put("img1", "https://github.com/akosighost/Home-image/raw/main/Compress_20220305_212232_2227.jpg");
			map_recyclerview1.put("role", "Fighter");
			map_recyclerview1.put("count", "33 Heroes Available");
			listmap_recyclerview1.add(map_recyclerview1);
			map_recyclerview1 = new HashMap<>();
			map_recyclerview1.put("img1", "https://github.com/akosighost/Home-image/raw/main/Compress_20220305_212232_2497.jpg");
			map_recyclerview1.put("role", "Mage");
			map_recyclerview1.put("count", "26 Heroes Available");
			listmap_recyclerview1.add(map_recyclerview1);
			map_recyclerview1 = new HashMap<>();
			map_recyclerview1.put("img1", "https://github.com/akosighost/Home-image/raw/main/Compress_20220305_212232_2867.jpg");
			map_recyclerview1.put("role", "Marksman");
			map_recyclerview1.put("count", "19 Heroes Available");
			listmap_recyclerview1.add(map_recyclerview1);
			map_recyclerview1 = new HashMap<>();
			map_recyclerview1.put("img1", "https://github.com/akosighost/Home-image/raw/main/Compress_20220305_212233_3147.jpg");
			map_recyclerview1.put("role", "Support");
			map_recyclerview1.put("count", "8 Heroes Available");
			listmap_recyclerview1.add(map_recyclerview1);
		}
		final CarouselLayoutManager recyclerview1layout = new CarouselLayoutManager(CarouselLayoutManager.HORIZONTAL,true); 
		recyclerview1layout.setPostLayoutListener(new CarouselZoomPostLayoutListener());
		recyclerview1.addOnScrollListener(new CenterScrollListener()); recyclerview1.setLayoutManager(recyclerview1layout); 
		recyclerview1.setHasFixedSize(true);
		recyclerview1.setAdapter(new Recyclerview1Adapter(listmap_recyclerview1));
		recyclerview1layout.addOnItemSelectionListener(new CarouselLayoutManager.OnCenterItemSelectionListener() { 
				@Override public void onCenterItemChanged(final int adapterPosition)
				 {
						 if (CarouselLayoutManager.INVALID_POSITION != adapterPosition) { 
								final int value = adapterPosition;
								textview9.setText(listmap_recyclerview1.get((int)/*recyclerview1*/value).get("role").toString());
					textview10.setText(listmap_recyclerview1.get((int)/*recyclerview1*/value).get("count").toString());
								 } } });
	}
	
	
	public void _Dialog(final boolean _show) {
		if (_show) {
			CustomDialog = new AlertDialog.Builder(HomeActivity.this).create();
			LayoutInflater CustomDialogLI = getLayoutInflater();
			View CustomDialogCV = (View) CustomDialogLI.inflate(R.layout.dialog, null);
			CustomDialog.setView(CustomDialogCV);
			CustomDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
			final ImageView i1 = (ImageView)
			CustomDialogCV.findViewById(R.id.imageview1);
			final TextView t1 = (TextView)
			CustomDialogCV.findViewById(R.id.textview1);
			final TextView t2 = (TextView)
			CustomDialogCV.findViewById(R.id.textview2);
			final TextView t3 = (TextView)
			CustomDialogCV.findViewById(R.id.textview3);
			final LinearLayout l1 = (LinearLayout)
			CustomDialogCV.findViewById(R.id.linear3);
			final LinearLayout l2 = (LinearLayout)
			CustomDialogCV.findViewById(R.id.linear2);
			final Button b1 = (Button)
			CustomDialogCV.findViewById(R.id.button1);
			android.graphics.drawable.GradientDrawable i1gd = new android.graphics.drawable.GradientDrawable();
						
						i1gd.setColor(0xFF2196F3);
						
						i1gd.setStroke((int)0, Color.TRANSPARENT);
						
						i1gd.setCornerRadii(new float[]{(int)100,(int)100,(int)100,(int)100,(int)100,(int)100,(int)100,(int)100});
						
						i1.setBackground(i1gd);
						
						i1.setElevation(5);
						{
								android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
								int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
								SketchUi.setColor(0xFF2196F3);
								SketchUi.setCornerRadius(d*160);
								android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFFFFFFF}), SketchUi, null);
								b1.setBackground(SketchUiRD);
								b1.setClickable(true);
						}
						android.graphics.drawable.GradientDrawable l2gd = new android.graphics.drawable.GradientDrawable();
						
						l2gd.setColor(0xFF2196F3);
						
						l2gd.setStroke((int)0, Color.TRANSPARENT);
						
						l2gd.setCornerRadii(new float[]{(int)100,(int)100,(int)100,(int)100,(int)100,(int)100,(int)100,(int)100});
						
						l2.setBackground(l2gd);
						
						l2.setElevation(5);
						android.graphics.drawable.GradientDrawable l1gd = new android.graphics.drawable.GradientDrawable();
						
						l1gd.setColor(0xFFFFFFFF);
						
						l1gd.setStroke((int)0, Color.TRANSPARENT);
						
						l1gd.setCornerRadii(new float[]{(int)50,(int)50,(int)50,(int)50,(int)50,(int)50,(int)50,(int)50});
						
						l1.setBackground(l1gd);
						
						l1.setElevation(5);
						i1.setElevation((float)0.3d);
			if (listmap_update.get((int)0).containsKey("image")) {
				if (listmap_update.get((int)0).get("image").toString().equals("true")) {
					i1.setVisibility(View.VISIBLE);
				}
				else {
					if (listmap_update.get((int)0).get("image").toString().equals("false")) {
						i1.setVisibility(View.INVISIBLE);
					}
				}
			}
			else {
				i1.setVisibility(View.INVISIBLE);
			}
			i1.setImageResource(R.drawable.update);
			b1.setText(listmap_update.get((int)0).get("button").toString().trim());
			t1.setText(listmap_update.get((int)0).get("title").toString().trim());
			t2.setText(listmap_update.get((int)0).get("details").toString().trim());
			t3.setText("Download size: ".concat(listmap_update.get((int)0).get("size").toString().concat(" MB")).trim());
			b1.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View _view){
					if (listmap_update.get((int)0).containsKey("link")) {
						intent.setAction(Intent.ACTION_VIEW);
						intent.setData(Uri.parse(listmap_update.get((int)0).get("link").toString()));
						startActivity(intent);
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "Unable to update");
					}
				}
			});
			CustomDialog.setCancelable(true);
			CustomDialog.show();
		}
		else {
			CustomDialog = new AlertDialog.Builder(HomeActivity.this).create();
			LayoutInflater CustomDialogLI = getLayoutInflater();
			View CustomDialogCV = (View) CustomDialogLI.inflate(R.layout.dialog, null);
			CustomDialog.setView(CustomDialogCV);
			CustomDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
			final ImageView i1 = (ImageView)
			CustomDialogCV.findViewById(R.id.imageview1);
			final TextView t1 = (TextView)
			CustomDialogCV.findViewById(R.id.textview1);
			final TextView t2 = (TextView)
			CustomDialogCV.findViewById(R.id.textview2);
			final TextView t3 = (TextView)
			CustomDialogCV.findViewById(R.id.textview3);
			final LinearLayout l1 = (LinearLayout)
			CustomDialogCV.findViewById(R.id.linear3);
			final LinearLayout l2 = (LinearLayout)
			CustomDialogCV.findViewById(R.id.linear2);
			final Button b1 = (Button)
			CustomDialogCV.findViewById(R.id.button1);
			android.graphics.drawable.GradientDrawable i1gd = new android.graphics.drawable.GradientDrawable();
						
						i1gd.setColor(0xFF2196F3);
						
						i1gd.setStroke((int)0, Color.TRANSPARENT);
						
						i1gd.setCornerRadii(new float[]{(int)100,(int)100,(int)100,(int)100,(int)100,(int)100,(int)100,(int)100});
						
						i1.setBackground(i1gd);
						
						i1.setElevation(5);
						{
								android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
								int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
								SketchUi.setColor(0xFF2196F3);
								SketchUi.setCornerRadius(d*160);
								android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFFFFFFF}), SketchUi, null);
								b1.setBackground(SketchUiRD);
								b1.setClickable(true);
						}
						android.graphics.drawable.GradientDrawable l2gd = new android.graphics.drawable.GradientDrawable();
						
						l2gd.setColor(0xFF2196F3);
						
						l2gd.setStroke((int)0, Color.TRANSPARENT);
						
						l2gd.setCornerRadii(new float[]{(int)100,(int)100,(int)100,(int)100,(int)100,(int)100,(int)100,(int)100});
						
						l2.setBackground(l2gd);
						
						l2.setElevation(5);
						android.graphics.drawable.GradientDrawable l1gd = new android.graphics.drawable.GradientDrawable();
						
						l1gd.setColor(0xFFFFFFFF);
						
						l1gd.setStroke((int)0, Color.TRANSPARENT);
						
						l1gd.setCornerRadii(new float[]{(int)50,(int)50,(int)50,(int)50,(int)50,(int)50,(int)50,(int)50});
						
						l1.setBackground(l1gd);
						
						l1.setElevation(5);
						i1.setElevation((float)0.3d);
			if (listmap_update.get((int)0).containsKey("image")) {
				if (listmap_update.get((int)0).get("image").toString().equals("true")) {
					i1.setVisibility(View.VISIBLE);
				}
				else {
					if (listmap_update.get((int)0).get("image").toString().equals("false")) {
						i1.setVisibility(View.INVISIBLE);
					}
				}
			}
			else {
				i1.setVisibility(View.INVISIBLE);
			}
			i1.setImageResource(R.drawable.update);
			b1.setText(listmap_update.get((int)0).get("button").toString().trim());
			t1.setText(listmap_update.get((int)0).get("title").toString().trim());
			t2.setText(listmap_update.get((int)0).get("details").toString().trim());
			t3.setText("Download size: ".concat(listmap_update.get((int)0).get("size").toString().concat(" MB")).trim());
			b1.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View _view){
					if (listmap_update.get((int)0).containsKey("link")) {
						intent.setAction(Intent.ACTION_VIEW);
						intent.setData(Uri.parse(listmap_update.get((int)0).get("link").toString()));
						startActivity(intent);
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "Unable to update");
					}
				}
			});
			CustomDialog.setCancelable(false);
			CustomDialog.show();
		}
	}
	
	
	public void _SetStatusBarColor(final String _color1, final String _color2) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) { 
			   Window w = this.getWindow(); w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS); w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			   w.setStatusBarColor(Color.parseColor(_color1)); w.setNavigationBarColor(Color.parseColor(_color2));
		}
	}
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.category, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			
			Glide.with(getApplicationContext())
			.load(_data.get((int)_position).get("img1").toString())
			.placeholder(R.drawable.transparent)
			.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)15))
			.into(imageview1);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					intent.setClass(getApplicationContext(), ListcategoryActivity.class);
					intent.putExtra("category", _data.get((int)_position).get("role").toString());
					intent.putExtra("count", _data.get((int)_position).get("count").toString());
					startActivity(intent);
					overridePendingTransition(R.anim.fin, R.anim.fout);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Recyclerview2Adapter extends RecyclerView.Adapter<Recyclerview2Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.pages, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_view.setLayoutParams(_lp);
			{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				SketchUi.setColor(0xFF0B141A);
				SketchUi.setCornerRadius(d*10);
				linear3.setElevation(d*5);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF9E9E9E}), SketchUi, null);
				linear3.setBackground(SketchUiRD);
				linear3.setClickable(true);
			}
			android.graphics.drawable.GradientDrawable linear2gd = new android.graphics.drawable.GradientDrawable();
			
			linear2gd.setColor(0xFF121F2B);
			
			linear2gd.setStroke((int)0, Color.TRANSPARENT);
			
			linear2gd.setCornerRadii(new float[]{(int)20,(int)20,(int)20,(int)20,(int)20,(int)20,(int)20,(int)20});
			
			linear2.setBackground(linear2gd);
			
			linear2.setElevation(50);
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("img1").toString())).into(imageview1);
			cardview1.setCardBackgroundColor(Color.TRANSPARENT);
			cardview1.setRadius((float)15);
			linear3.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (_data.get((int)_position).containsKey("click")) {
						if (_data.get((int)_position).get("click").toString().equals("false")) {
							SketchwareUtil.showMessage(getApplicationContext(), "Not available for now");
						}
					}
					else {
						intent.setClass(getApplicationContext(), EffectsActivity.class);
						intent.putExtra("effect", _data.get((int)_position).get("txt1").toString());
						intent.putExtra("count", _data.get((int)_position).get("txt2").toString());
						intent.putExtra("data", _data.get((int)_position).get("api").toString());
						startActivity(intent);
						overridePendingTransition(R.anim.fin, R.anim.fout);
					}
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}