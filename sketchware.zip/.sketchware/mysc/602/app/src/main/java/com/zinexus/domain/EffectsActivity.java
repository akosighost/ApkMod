package com.zinexus.domain;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.azoft.carousellayoutmanager.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.bumptech.glide.Glide;
import com.downloader.*;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.kaopiz.kprogresshud.*;
import com.twotoasters.jazzylistview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import jp.wasabeef.picasso.transformations.*;
import me.everything.*;
import org.json.*;
import java.io.*;
import java.util.zip.*;
import androidx.documentfile.provider.DocumentFile;
import android.provider.DocumentsContract;
import android.database.*;
import android.provider.DocumentsContract.Document;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;

public class EffectsActivity extends AppCompatActivity {
	
	private String api = "";
	private double size = 0;
	private HashMap<String, Object> sumCount = new HashMap<>();
	private String file = "";
	private String filename = "";
	private  Uri muri;
	private  Uri suri;
	private  Uri urit;
	private  DocumentFile file1;
	private  DocumentFile file2;
	private  DocumentFile f3;
	private  DocumentFile f4;
	private  DocumentFile filepath;
	private  DocumentFile path;
	private  DocumentFile path1;
	private  static final int NEW_FOLDER_REQUEST_CODE = 43;
	private  Runnable runnable;
	private  Uri uri1;
	private  Dialog dialog;
	private  DocumentFile mfile;
	private  Uri uri2;
	private String release = "";
	private  DocumentFile mfile1;
	private double length = 0;
	private double number = 0;
	private String value = "";
	
	private ArrayList<HashMap<String, Object>> listmap_listview1 = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear9;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private TextView textview1;
	private LinearLayout linear8;
	private TextView textview2;
	private LinearLayout linear10;
	private LinearLayout linear13;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private EditText edittext1;
	private JazzyListView listview1;
	
	private RequestNetwork internet;
	private RequestNetwork.RequestListener _internet_request_listener;
	private Intent intent = new Intent();
	private SharedPreferences save;
	private  CustomToast;
	private  CustomDialog;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.effects);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear9 = findViewById(R.id.linear9);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		textview1 = findViewById(R.id.textview1);
		linear8 = findViewById(R.id.linear8);
		textview2 = findViewById(R.id.textview2);
		linear10 = findViewById(R.id.linear10);
		linear13 = findViewById(R.id.linear13);
		linear11 = findViewById(R.id.linear11);
		linear12 = findViewById(R.id.linear12);
		edittext1 = findViewById(R.id.edittext1);
		listview1 = findViewById(R.id.listview1);
		internet = new RequestNetwork(this);
		save = getSharedPreferences("save", Activity.MODE_PRIVATE);
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				try {
					listmap_listview1 = new Gson().fromJson(api, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					length = listmap_listview1.size();
					number = length - 1;
					for(int _repeat18 = 0; _repeat18 < (int)(length); _repeat18++) {
						value = listmap_listview1.get((int)number).get("txt1").toString();
						if (!(_charSeq.length() > value.length()) && value.toLowerCase().contains(_charSeq.toLowerCase())) {
							
						}
						else {
							listmap_listview1.remove((int)(number));
							listview1.setAdapter(new Listview1Adapter(listmap_listview1));
						}
						number--;
					}
					listview1.setAdapter(new Listview1Adapter(listmap_listview1));
				} catch (Exception e) {
					 
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		_internet_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try {
					save.edit().putString("effect_response", _response).commit();
					listmap_listview1 = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					listview1.setAdapter(new Listview1Adapter(listmap_listview1));
					((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					api = new Gson().toJson(listmap_listview1);
				} catch (Exception e) {
					 
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				try {
					listmap_listview1 = new Gson().fromJson(save.getString("effect_response", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					listview1.setAdapter(new Listview1Adapter(listmap_listview1));
					((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					api = new Gson().toJson(listmap_listview1);
				} catch (Exception e) {
					 
				}
			}
		};
	}
	
	private void initializeLogic() {
		_SetStatusBarColor("#0B141D", "#0B141D");
		if (getIntent().hasExtra("data")) {
			internet.startRequestNetwork(RequestNetworkController.GET, getIntent().getStringExtra("data"), "a", _internet_request_listener);
		}
		else {
			
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF121F2B);
			SketchUi.setCornerRadius(d*12);
			linear3.setElevation(d*5);
			linear3.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF121F2B);SketchUi.setCornerRadii(new float[]{
				d*0,d*0,d*0 ,d*0,d*25,d*25 ,d*25,d*25});
			linear12.setElevation(d*5);
			linear12.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF121F2B);SketchUi.setCornerRadii(new float[]{
				d*15,d*15,d*15 ,d*15,d*0,d*0 ,d*0,d*0});
			linear13.setElevation(d*5);
			linear13.setBackground(SketchUi);
		}
		listview1.setHorizontalScrollBarEnabled(false);
		listview1.setVerticalScrollBarEnabled(false);
		listview1.setOverScrollMode(ListView.OVER_SCROLL_NEVER);
		OverScrollDecoratorHelper.setUpOverScroll(listview1);
		if (getIntent().hasExtra("effect")) {
			textview1.setText(getIntent().getStringExtra("effect"));
		}
		if (getIntent().hasExtra("count")) {
			textview2.setText(getIntent().getStringExtra("count").concat(" ".concat(getIntent().getStringExtra("effect").concat(" Available"))));
		}
		listview1.setTransitionEffect(new com.twotoasters.jazzylistview.effects.SlideInEffect());
		edittext1.setFilters(new InputFilter[]{new InputFilter.LengthFilter((int) 40)});
		edittext1.setCursorVisible(false);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		    if (_data != null) {
				               muri = _data.getData();
				if (Uri.decode(muri.toString()).endsWith(":")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Can't use root folder please choose another");
						_AskPermission(linear1);
				}
				else {
						final int takeFlags = intent.getFlags()
						            & (Intent.FLAG_GRANT_READ_URI_PERMISSION
						            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
						// Check for the freshest data.
						getContentResolver().takePersistableUriPermission(muri, takeFlags);
						save.edit().putString("FOLDER_URI", muri.toString()).commit();
						    mfile = DocumentFile.fromTreeUri(this, muri);
						                    
						    mfile1 = mfile.createFile("*/*", "test.file");
						    uri2 = mfile1.getUri();
						save.edit().putString("DIRECT_FOLDER_URI", uri2.toString().substring((int)(0), (int)(uri2.toString().length() - 9))).commit();
						try{
								        DocumentsContract.deleteDocument(getApplicationContext().getContentResolver(), uri2);
								     
								        } catch (FileNotFoundException e) {
								         
								    }             
				}
				       } else {
				        
				   }
		    if (_resultCode == Activity.RESULT_OK) {
				        CustomDialog.dismiss();
				SketchwareUtil.showMessage(getApplicationContext(), "Permission Granted");
				       } else {
				       CustomDialog.dismiss();
				SketchwareUtil.showMessage(getApplicationContext(), "Permission Denied");
				   }
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		startActivity(new Intent(EffectsActivity.this, HomeActivity.class)); Animatoo.animateFade(EffectsActivity.this);
	}
	
	public void _SetStatusBarColor(final String _color1, final String _color2) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) { 
			   Window w = this.getWindow(); w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS); w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			   w.setStatusBarColor(Color.parseColor(_color1)); w.setNavigationBarColor(Color.parseColor(_color2));
		}
	}
	
	
	public void _inject() {
	}
	private class Auto11 extends AsyncTask<String, Integer, String> {
		KProgressHUD hud;
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			hud = new KProgressHUD(EffectsActivity.this).setStyle(KProgressHUD.Style.ANNULAR_DETERMINATE).setLabel("Please Wait..")
			.setMaxProgress(100);
			 
			hud.show();
			
		}
		String filename = "";
		String result = "";
		double size = 0;
		double sumCount = 0;
		 @Override
		protected String doInBackground(String... address) {
					try {
								filename= URLUtil.guessFileName(address[0], null, null);
				urit = Uri.parse(save.getString("DIRECT_FOLDER_URI", ""));
				path = DocumentFile.fromTreeUri(EffectsActivity.this, urit);
				path1 = path.createFile("*/*", filename.toLowerCase());
				int resCode = -1;
										java.io.InputStream in = null;
										java.net.URL url = new java.net.URL(address[0]);
										java.net.URLConnection urlConn = url.openConnection();
										if (!(urlConn instanceof java.net.HttpURLConnection)) {
													throw new java.io.IOException("URL is not an Http URL"); }
										java.net.HttpURLConnection httpConn = (java.net.HttpURLConnection) urlConn; httpConn.setAllowUserInteraction(false); httpConn.setInstanceFollowRedirects(true); httpConn.setRequestMethod("GET"); httpConn.connect();
										resCode = httpConn.getResponseCode();
										if (resCode == java.net.HttpURLConnection.HTTP_OK) {
													in = httpConn.getInputStream();
													size = httpConn.getContentLength();
													
										} else { result = "There was an error"; }
				OutputStream output = getContentResolver().openOutputStream(path1.getUri());
						
						try {
									int bytesRead;
									sumCount = 0;
									byte[] buffer = new byte[1024];
									while ((bytesRead = in.read(buffer)) != -1) {
												output.write(buffer, 0, bytesRead);
												sumCount += bytesRead;
												if (size > 0) {
															publishProgress((int)Math.round(sumCount*100 / size));
												}
									}
						} finally {
									output.close();
						}
						result ="";
						in.close();
			} catch (java.net.MalformedURLException e) {
						result = e.getMessage();
			} catch (java.io.IOException e) {
						result = e.getMessage();
			} catch (Exception e) {
						result = e.toString();
			}
				return result;
				
		}
		@Override
		protected void onProgressUpdate(Integer... values) {
				super.onProgressUpdate(values);
			hud.setProgress(values[values.length - 1]);
			hud.setDetailsLabel(String.valueOf((long)(values[values.length - 1])).concat("%"));
		}
		protected void onPostExecute(String s){
				file = filename;
			suri = Uri.parse(save.getString("DIRECT_FOLDER_URI", ""));
			urit = Uri.parse(save.getString("DIRECT_FOLDER_URI", "").concat(filename.toLowerCase())); 
			filepath = DocumentFile.fromTreeUri(EffectsActivity.this, urit);
				Decompress d = new Decompress(filepath, path, EffectsActivity.this); 
				d.execute();
		}
	}
	private class Decompress extends AsyncTask<Void, Integer, Integer> { 
		DocumentFile srcZipFile;
		DocumentFile destDir;
		Context ctx;
		int result = 0;
		final AlertDialog.Builder dialog = new AlertDialog.Builder(EffectsActivity.this);
		final AlertDialog unzipDialog = dialog.create();
		final View inflate = getLayoutInflater().inflate(R.layout.unzip, null);
		LinearLayout l2 = inflate.findViewById(R.id.linear2);
		LinearLayout l3 = inflate.findViewById(R.id.linear3);
		TextView t2 = inflate.findViewById(R.id.textview2);
		public Decompress(DocumentFile srcZipFile, DocumentFile destDir, Context ctx) {
			super();		
			this.srcZipFile = srcZipFile; 		
			this.destDir = destDir;		
			this.ctx = ctx;
		}
		
		@Override	protected void onPreExecute() {
			{
					android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
					int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
					SketchUi.setColor(0xFFE0E0E0);SketchUi.setCornerRadii(new float[]{
							d*10,d*10,d*0 ,d*0,d*0,d*0 ,d*10,d*10});
					l2.setBackground(SketchUi);
			}
			{
					android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
					int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
					SketchUi.setColor(0xFF121F2B);SketchUi.setCornerRadii(new float[]{
							d*0,d*0,d*10 ,d*10,d*10,d*10 ,d*0,d*0});
					l3.setBackground(SketchUi);
			}
			unzipDialog.setView(inflate);
			unzipDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
			unzipDialog.setCancelable(false);
			unzipDialog.show();
		}
		 @Override
		protected Integer doInBackground(Void... params){		
				int count = 0;
				
				
				try {
						ZipEntry entry; 
						InputStream inputStream = getContentResolver().openInputStream(srcZipFile.getUri()); 
						
						BufferedInputStream bis = new BufferedInputStream(inputStream);
						
						java.util.zip.ZipInputStream zipInputStream = new java.util.zip.ZipInputStream(bis);
						
						int numFiles = 0;
						
						 
						
						
						while ((entry = zipInputStream.getNextEntry()) != null) { 
								DocumentFile currentDestDir = destDir; 
								DocumentFile parentDir = destDir; 
								DocumentFile childDir = null;
								count++;
								publishProgress((int)count);
								
								if (entry.toString().endsWith("/")) { 
										
										String[] tempStr = entry.toString().split("/"); 
										
										
										 for (String st : tempStr) { 
												
												if (st == "UI"){
														childDir = parentDir.findFile(st.toUpperCase());
														
														if (childDir == null) { 
																childDir = parentDir.createDirectory(st);
														}
														
												}else{
														childDir = parentDir.findFile(st);
														
														if (childDir == null) { 
																childDir = parentDir.createDirectory(st);
														}
														
												}
												 
												parentDir = childDir; 
										} 
										// returns null 
								}
								
								else if (entry.toString().contains("/")) { 
										
										String[] tempStr = entry.toString().split("/"); 
										
										for (int i = 0; i < tempStr.length - 1; i++) { 
												
												childDir = parentDir.findFile(tempStr[i]); 
												
												if (childDir == null){ 
														childDir = parentDir.createDirectory(tempStr[i]); } 
												parentDir = childDir; 
										} 
										String finalFileName = entry.toString().substring(entry.toString().lastIndexOf("/") + 1); 
										
										unzipFile(entry, zipInputStream, parentDir);
										
										
										 } // Like ---> / 
								else if (entry.toString().equals("/")) 
								{
										 
										 } else { 
										unzipFile(entry, zipInputStream, destDir);
										
										
								}
						}
						inputStream.close(); 
						 }catch(IOException e1){
						//toast
						SketchwareUtil.showMessage(getApplicationContext(), e1.toString());
						
						 } 
				
				return result;
				
		} 
		private void unzipFile(ZipEntry fileEntry, java.util.zip.ZipInputStream zipInputStream, DocumentFile finalDir) throws IOException {
				 int readLen; 
				
				if (!fileEntry.isDirectory()) {
						DocumentFile tempFile = null;
						DocumentFile df = null;
														
														
														//Now you have to tell it what file extensions ("MIME" type) you want to use, e.g.:
						
						
						tempFile = DocumentFile.fromSingleUri(EffectsActivity.this, Uri.parse(finalDir.getUri().toString().concat(Uri.encode("/").concat(Uri.parse(fileEntry.toString()).getLastPathSegment()))));
						
						
						if (tempFile.exists()) {
								
								df = tempFile;
									
						}else {
								
								df = finalDir.createFile("*/*",  Uri.parse(fileEntry.toString()).getLastPathSegment());
						}
							
						try {
								
								OutputStream out = getContentResolver().openOutputStream(df.getUri());
																BufferedOutputStream bos = new BufferedOutputStream(out);
								long zipfilesize = fileEntry.getSize();
								
								byte[] buffer = new byte[4096];
																int len = 0;
																int totlen = 0;
								
								int count = -1;
								while ((count = zipInputStream.read(buffer)) != -1)
								{
										out.write(buffer, 0, count);
								}
								out.close(); 
								bos.close();
								
								 }catch(Exception e2){
								
								final String e22 = e2.toString();
								runOnUiThread(new Runnable() { 
										public void run() { 
												SketchwareUtil.showMessage(getApplicationContext(), e22);
										}});
								
						}
						
				}
		}
		
		protected void onProgressUpdate(Integer... progress) {
			t2.setText(String.valueOf(progress[progress.length - 1]).concat(" Files Extracted.."));
		}
		@Override
		protected void onPostExecute(Integer result) {
				filepath = DocumentFile.fromTreeUri(EffectsActivity.this, urit);
			try{
					        DocumentsContract.deleteDocument(getApplicationContext().getContentResolver(), urit);
				urit = Uri.parse(save.getString("DIRECT_FOLDER_URI", "").concat(file.toLowerCase())); 
				unzipDialog.dismiss();
				LayoutInflater CustomToastLT = getLayoutInflater(); 
				View CustomToastVT = CustomToastLT.inflate(R.layout.success, null);
				Toast CustomToastT = Toast.makeText(getApplicationContext(),"",500);
				CustomToastT.setView(CustomToastVT);
				CustomToastT.show();
			} catch (FileNotFoundException e) {
				unzipDialog.dismiss();
				SketchwareUtil.showMessage(getApplicationContext(), "Failed to Inject");
			}
		}
	}
	
	
	public void _MoreBlock() {
	}
	
	Boolean Ikuza (DocumentFile srcZipFile, DocumentFile destDir) {
		
		try {
			
			ZipEntry entry; 
			InputStream inputStream = getContentResolver().openInputStream(srcZipFile.getUri()); 
			
			BufferedInputStream bis = new BufferedInputStream(inputStream);
			
			java.util.zip.ZipInputStream zipInputStream = new java.util.zip.ZipInputStream(bis);
			
			
			 
			while ((entry = zipInputStream.getNextEntry()) != null) { 
				DocumentFile currentDestDir = destDir; 
				DocumentFile parentDir = destDir; 
				DocumentFile childDir = null;
				
				if (entry.toString().endsWith("/")) { 
					
					String[] tempStr = entry.toString().split("/"); 
					
					
					 for (String st : tempStr) { 
						
						String meta = Arrays.toString(tempStr);
						if(meta == "Ui"){
							childDir = parentDir.findFile(meta.toUpperCase());
							if (childDir == null) { 
								
								childDir = parentDir.createDirectory(st);
								//swtchend
							} 
						}else{
							childDir = parentDir.findFile(st);
							if (childDir == null) { 
								
								childDir = parentDir.createDirectory(st);
								//swtchend
							} 
						}
						
						 
						parentDir = childDir; 
					} 
					// returns null 
				}
				
				else if (entry.toString().contains("/")) { 
					
					String[] tempStr = entry.toString().split("/"); 
					
					for (int i = 0; i < tempStr.length - 1; i++) { 
						
						childDir = parentDir.findFile(tempStr[i]); 
						
						if (childDir == null){ 
							childDir = parentDir.createDirectory(tempStr[i]); } 
						parentDir = childDir; 
					} 
					String finalFileName = entry.toString().substring(entry.toString().lastIndexOf("/") + 1); 
					
					unzipFile(entry, zipInputStream, parentDir);
					
					
					 } // Like ---> / 
				else if (entry.toString().equals("/")) 
				{
					 
					 } else { 
					unzipFile(entry, zipInputStream, destDir);
					
					
				}
			}
			inputStream.close(); 
			 }catch(IOException e1){
			//toast
			SketchwareUtil.showMessage(getApplicationContext(), e1.toString());
			return false;
			 } 
		return true;
		
	} 
	private void unzipFile(ZipEntry fileEntry, java.util.zip.ZipInputStream zipInputStream, DocumentFile finalDir) throws IOException {
		 int readLen; 
		
		if (!fileEntry.isDirectory()) {
			DocumentFile tempFile = null;
			DocumentFile df = null;
											
											
											//Now you have to tell it what file extensions ("MIME" type) you want to use, e.g.:
			
			
			tempFile = DocumentFile.fromSingleUri(this, Uri.parse(finalDir.getUri().toString().concat(Uri.encode("/").concat(Uri.parse(fileEntry.toString()).getLastPathSegment()))));
			
			
			if (tempFile.exists()) {
				
				df = tempFile;
					
			}else {
				
				df = finalDir.createFile("*/*",  Uri.parse(fileEntry.toString()).getLastPathSegment());
			}
				
			try {
				
				OutputStream out = getContentResolver().openOutputStream(df.getUri());
												BufferedOutputStream bos = new BufferedOutputStream(out);
				long zipfilesize = fileEntry.getSize();
				
				byte[] buffer = new byte[4096];
												int len = 0;
												int totlen = 0;
				
				int count = -1;
				while ((count = zipInputStream.read(buffer)) != -1)
				{
					out.write(buffer, 0, count);
				}
				out.close(); 
				bos.close();
				
				 }catch(Exception e2){
				//toast
				SketchwareUtil.showMessage(getApplicationContext(), e2.toString());
				
			}
			
		}
		 }
	
	{
	}
	boolean hasManageExternalStoragePermission() 
	{
		 if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) { 
			if (Environment.isExternalStorageManager()) {
				 return true;
				 } else {
				 if (Environment.isExternalStorageLegacy()) { return true; 
				} 
				try { 
					Intent intent = new Intent(); intent.setAction(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION); intent.setData(Uri.parse("package:".concat(getApplicationContext().getPackageName().toString())
					)); 
					startActivityForResult(intent, 1);
					  
					return false; 
				} catch (Exception e) { 
					return false; 
				}
				 }
			 } 
		{
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) { 
				if (Environment.isExternalStorageLegacy()) { 
					return true;
					 } else {
					 try { 
						Intent intent = new Intent(); intent.setAction(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION); intent.setData(Uri.parse("package:".concat(getApplicationContext().getPackageName().toString())
						)); 
						startActivityForResult(intent, 1); 
						
						return false;
						 } catch (Exception e) { 
						return true; 
					} 
				} 
			}
			 return true; 
		}
	}
	Boolean CyberUnzip(String destDir,String fileZip){
		try
		{
			java.io.File outdir = new java.io.File(destDir);
			java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(new java.io.FileInputStream(fileZip));
			java.util.zip.ZipEntry entry;
			String name, dir;
			while ((entry = zin.getNextEntry()) != null)
			{
				name = entry.getName();
				if(entry.isDirectory())
				{
					mkdirs(outdir, name);
					continue;
				}
				
				/* this part is necessary because file entry can come before
* directory entry where is file located
* i.e.:
* /foo/foo.txt
* /foo/
*/
				
				dir = dirpart(name);
				if(dir != null)
				mkdirs(outdir, dir);
				
				extractFile(zin, outdir, name);
			}
			zin.close();
		}
		catch (java.io.IOException e)
		{
			return false;
		}
		return true;
		
	}
	private static void extractFile(java.util.zip.ZipInputStream in, java.io.File outdir, String name) throws java.io.IOException
	{
		byte[] buffer = new byte[4096];
		java.io.BufferedOutputStream out = new java.io.BufferedOutputStream(new java.io.FileOutputStream(new java.io.File(outdir, name)));
		int count = -1;
		while ((count = in.read(buffer)) != -1)
		out.write(buffer, 0, count);
		out.close();
	}
	
	private static void mkdirs(java.io.File outdir, String path)
	{
		java.io.File d = new java.io.File(outdir, path);
		if(!d.exists())
		d.mkdirs();
	}
	
	private static String dirpart(String name)
	{
		int s = name.lastIndexOf(java.io.File.separatorChar);
		return s == -1 ? null : name.substring(0, s);
	}
	{
	}
	
	
	public void _PermissionDialog() {
		CustomDialog = new AlertDialog.Builder(EffectsActivity.this).create();
		LayoutInflater CustomDialogLI = getLayoutInflater();
		View CustomDialogCV = (View) CustomDialogLI.inflate(R.layout.permission, null);
		CustomDialog.setView(CustomDialogCV);
		CustomDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		final TextView t1 = (TextView)
		CustomDialogCV.findViewById(R.id.textview1);
		final LinearLayout l5 = (LinearLayout)
		CustomDialogCV.findViewById(R.id.linear5);
		t1.setText("A N D R O I D  ".concat(release));
		l5.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View _view){
				_AskPermission(linear1);
			}
		});
		CustomDialog.setCancelable(true);
		CustomDialog.show();
	}
	
	
	public void _AskPermission(final View _view) {
		intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
		intent.setAction(Intent.ACTION_OPEN_DOCUMENT_TREE);
		muri = Uri.parse("content://com.android.externalstorage.documents/tree/primary%3AAndroid/document/primary%3AAndroid%2Fdata%2Fcom.mobile.legends%2Ffiles%2Fdragon2017");
		    intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, muri);
		        startActivityForResult(intent, NEW_FOLDER_REQUEST_CODE);
	}
	
	
	public void _InjectEffect(final double _position, final ArrayList<HashMap<String, Object>> _data) {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
				try {
				muri = Uri.parse(save.getString("DIRECT_FOLDER_URI", ""));
				    mfile = DocumentFile.fromTreeUri(this, muri);
				                    
				if (!mfile.canRead() || !mfile.canWrite()) {
					_PermissionDialog();
				}
				else {
					if (_data.get((int)_position).containsKey("url")) {
						new Auto11().execute(_data.get((int)_position).get("url").toString().replace("blob", "raw"));
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "No link Available");
					}
				}
			} catch (Exception e) {
				_PermissionDialog();
			}	 
			}else{
					 if (Build.VERSION.SDK_INT >= 23) {
							if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_DENIED) {
									requestPermissions(new String[] {android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
							}
							else {
					if (_data.get((int)_position).containsKey("url")) {
						DownloaderDialogFragmentActivity z = new DownloaderDialogFragmentActivity();
						z.show( getSupportFragmentManager(),"");
						save.edit().putString("link", _data.get((int)_position).get("url").toString().replace("blob", "raw")).commit();
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "No link Available");
					}
							}
					}
					else {
				if (_data.get((int)_position).containsKey("url")) {
					DownloaderDialogFragmentActivity z = new DownloaderDialogFragmentActivity();
					z.show( getSupportFragmentManager(),"");
					save.edit().putString("link", _data.get((int)_position).get("url").toString().replace("blob", "raw")).commit();
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "No link Available");
				}
					}
			}
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.effect, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				SketchUi.setColor(0xFF121F2B);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF9E9E9E}), SketchUi, null);
				linear1.setBackground(SketchUiRD);
				linear1.setClickable(true);
			}
			Animation animation; animation = AnimationUtils.loadAnimation( getApplicationContext(), android.R.anim.fade_in ); animation.setDuration(700); linear1.startAnimation(animation); animation = null;
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("img1").toString())).into(imageview1);
			cardview1.setCardBackgroundColor(Color.TRANSPARENT);
			cardview1.setRadius((float)10);
			if (_data.get((int)_position).containsKey("click")) {
				if (_data.get((int)_position).get("click").toString().equals("false")) {
					textview1.setText("Not working");
					textview1.setTextColor(0xFFF44336);
				}
			}
			else {
				textview1.setText(_data.get((int)_position).get("txt1").toString());
				textview1.setTextColor(0xFF757575);
			}
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (SketchwareUtil.isConnected(getApplicationContext())) {
						if (_data.get((int)_position).containsKey("click")) {
							if (_data.get((int)_position).get("click").toString().equals("false")) {
								SketchwareUtil.showMessage(getApplicationContext(), "Not available for now");
							}
						}
						else {
							_InjectEffect(_position, _data);
						}
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "Please check your internet connection");
					}
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}